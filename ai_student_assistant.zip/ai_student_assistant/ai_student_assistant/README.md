# AI Student Assistant — NLP-Based Personalized Academic Assistant

A ChatGPT-style chat companion for your own study material, with real
accounts, persistent chat history, and a handful of extra tools tucked
into the sidebar: Explain Mode, Summarizer, Quiz, Compare, and Progress.

> **Design principle:** retrieval, chunking, summarization, quiz
> generation, and comparison are all done with explicit, inspectable NLP
> techniques (tokenization → chunking → embeddings → similarity search →
> extraction) — not by piping your whole document + question to an LLM.
> A free LLM API is used *only* to phrase the final chat answer more
> naturally; if it's not configured (or fails), the app automatically
> falls back to a fully offline, extractive answer. This makes it
> demonstrable in a viva: you can point to the exact function that does
> tokenization, TF-IDF keyword extraction, TextRank summarization, etc.

---

## 1. What's new: accounts + chat

- **Login / Register** — a local account system (username + salted,
  hashed password) stored in `data/users.json`. Nothing leaves your
  machine.
- **Your document, chats, and progress are saved to your account** — log
  back in later and everything is right where you left it.
- **ChatGPT-style chat** as the main experience — a sidebar list of past
  conversations, a "+ New chat" button, and a chat window that's grounded
  in your notes via semantic search (RAG), with a free LLM API used only
  to phrase the answer naturally.
- **Works with zero API key** — without one, Chat automatically falls
  back to a fully offline, extractive answer. Nothing breaks either way.

## 2. Features

| # | Feature | Where |
|---|---|---|
| 1 | 💬 Chat — context-aware, RAG-grounded conversation over your notes | Main page, `modules/qa_engine.py` |
| 2 | 🎓 Explain Mode — Normal / Simple / Example / Exam / Detail | Sidebar tool, `modules/explain_engine.py` |
| 3 | 📝 Summarizer — Quick Revision / Standard / Exam Notes | Sidebar tool, `modules/summarizer.py` |
| 4 | 🧠 Quiz + Evaluation — MCQ / True-False / Short Answer, weak-topic detection | Sidebar tool, `modules/quiz_engine.py` |
| 5 | ⚖️ Compare Mode — "difference between X and Y" tables | Sidebar tool, `modules/comparison_engine.py` |
| 6 | 📊 Progress — score-based mastery tracking + revision tips | Sidebar tool, `modules/progress_tracker.py` |

Supporting pipeline: `modules/extraction.py` (PDF/DOCX/TXT text extraction),
`modules/preprocessing.py` (cleaning, tokenization, stopword removal,
stemming, TF-IDF keyword extraction, chunking), `modules/embeddings_store.py`
(semantic vector search), `modules/auth.py` (local accounts),
`modules/storage.py` (per-user persistence), `modules/llm_client.py`
(free LLM API wrapper).

---

## 3. Setting up the free chat API (optional but recommended)

Chat works without this — it just uses the offline extractive pipeline.
To get natural, conversational answers:

1. Go to **[console.groq.com/keys](https://console.groq.com/keys)** and
   sign up (free, no credit card).
2. Create an API key and copy it.
3. In the app, open **⚙️ Settings** in the sidebar, paste the key, hit
   **Test connection**, then **Save**.
4. Optionally check "Remember this key on this device" so you don't have
   to paste it again next time (it's stored locally in a plain JSON file
   under `data/user_data/<you>/settings.json` — never uploaded anywhere).

OpenRouter (also free, no card) is available as a second provider in the
same Settings dropdown if you'd rather use that.

> Only the final answer's *wording* comes from the LLM. Which passages of
> your notes are relevant is still decided entirely by local semantic
> search (`modules/embeddings_store.py`) — the LLM never sees your whole
> document, only the specific retrieved chunks for each question.

---

## 4. NLP concepts demonstrated (for your viva)

- **Text preprocessing**: regex-based sentence segmentation, tokenization,
  stopword removal, Porter stemming (`modules/preprocessing.py`)
- **Vector semantics / embeddings**: `sentence-transformers` (all-MiniLM-L6-v2)
  sentence embeddings with cosine similarity for semantic search
  (`modules/embeddings_store.py`); automatically falls back to a TF-IDF
  vector space model if the transformer model can't be downloaded.
- **Retrieval-augmented generation (RAG)**: `modules/qa_engine.py` retrieves
  the most relevant chunks locally, then (optionally) hands only those
  chunks to a free LLM API to phrase the answer — the retrieval step is
  the part that's actually graded NLP work.
- **Context-aware NLU**: follow-up/pronoun resolution so "explain it
  simply" continues the previous topic, both in the offline fallback
  (regex-based) and implicitly via real conversation history when the
  LLM is used.
- **Extractive summarization**: TextRank (TF-IDF sentence graph + PageRank
  via `networkx`) to identify the most central/important sentences.
- **Keyword/keyphrase extraction**: TF-IDF based extraction, used across
  chunking, explanation, summarization, and quiz generation.
- **Question generation**: concept/definition mining via copula patterns,
  MCQ distractor generation, True/False statement corruption via
  rule-based negation (`modules/quiz_engine.py`).
- **Pattern-based comparison extraction**: regex detection of comparison
  questions + feature-bucketed sentence extraction
  (`modules/comparison_engine.py`).
- **Local authentication**: PBKDF2-HMAC-SHA256 password hashing with a
  per-user random salt (`modules/auth.py`) — stdlib only, no extra
  dependency.

---

## 5. Setup

### Requirements
- Python 3.9+
- Internet access **the first time** you run it, for two things:
  1. downloading the `all-MiniLM-L6-v2` sentence-transformer model (~90MB,
     cached afterwards) — if unavailable, the app automatically falls back
     to TF-IDF retrieval instead;
  2. calling the free LLM API for chat, if you've configured a key —
     entirely optional, see section 3 above.

### Install

```bash
cd ai_student_assistant
pip install -r requirements.txt
```

### Run

```bash
streamlit run app.py
```

Then open the URL Streamlit prints (typically `http://localhost:8501`).

---

## 6. How to use it

1. **Register** an account (or log in if you already have one).
2. **Upload** a PDF, DOCX, or TXT file of your notes — this is saved to
   your account.
3. You land on **💬 Chat** — ask anything about your notes. Follow-ups
   like "explain it simply" or "what are its advantages?" just work.
4. Use **➕ New chat** to start a fresh conversation thread; past threads
   stay listed in the sidebar.
5. Use the sidebar **Tools** — Explain Mode, Summarizer, Quiz, Compare,
   Progress — for the more structured, single-purpose features.
6. **⚙️ Settings** lets you add a free LLM API key for more natural chat
   answers (optional — see section 3).
7. **🔄 Change document** swaps out your notes; **🚪 Log out** ends your
   session (your data stays saved for next time).

---

## 7. Project structure

```
ai_student_assistant/
├── app.py                       # Streamlit UI — auth, chat, sidebar, tools
├── requirements.txt
├── README.md
├── .streamlit/
│   └── config.toml              # forces a light theme (avoids dark-mode contrast bugs)
├── data/                         # created at runtime — accounts + per-user data
│   ├── users.json
│   └── user_data/<username>/
│       ├── document.json         # saved chunks of the uploaded notes
│       ├── conversations.json    # chat history
│       ├── progress.json         # quiz mastery record
│       └── settings.json         # LLM provider + (optionally) remembered API key
└── modules/
    ├── auth.py                   # local account system (PBKDF2 password hashing)
    ├── storage.py                # per-user JSON persistence
    ├── llm_client.py             # free LLM API wrapper (Groq / OpenRouter)
    ├── extraction.py             # PDF/DOCX/TXT text extraction
    ├── preprocessing.py          # cleaning, tokenization, chunking, keywords
    ├── embeddings_store.py       # semantic vector search (+ TF-IDF fallback)
    ├── qa_engine.py              # context-aware Q&A + RAG chat generation
    ├── explain_engine.py         # adaptive explanation modes
    ├── summarizer.py             # extractive summarization (TextRank)
    ├── quiz_engine.py            # quiz generation + grading
    ├── intent_classifier.py      # (kept for NLP demo purposes; not wired into nav)
    ├── comparison_engine.py      # comparison-question detection + tables
    └── progress_tracker.py       # mastery tracking + recommendations
```

## 8. Notes on security

This is a local, single-machine student project, not a hardened
production auth system: passwords are salted + hashed (never stored in
plaintext), but there's no email verification, rate limiting, or HTTPS —
don't reuse an important password here, and don't expose this app to the
open internet as-is.
