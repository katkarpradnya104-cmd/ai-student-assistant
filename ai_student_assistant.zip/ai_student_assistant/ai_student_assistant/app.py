"""
AI Student Assistant
=====================
An NLP-based personalized academic assistant with real accounts and a
ChatGPT-style chat interface. Log in, upload your study material once
(it's remembered on your account), and chat with your notes — grounded
by real semantic retrieval over your own document, with a free LLM API
used only to phrase the final answer naturally. A handful of extra tools
(Explain / Summarize / Quiz / Compare / Progress) live in the sidebar.

Run with:
    streamlit run app.py
"""

import uuid
import time
import os

import streamlit as st
from modules import auth, storage
from modules.extraction import extract_document
from modules.preprocessing import chunk_text, sent_tokenize
from modules.embeddings_store import EmbeddingStore
from modules.qa_engine import answer_question, llm_chat_answer
from modules.explain_engine import explain
from modules.summarizer import summarize
from modules.quiz_engine import generate_quiz, grade_quiz
from modules.comparison_engine import detect_comparison, build_comparison
from modules.llm_client import PROVIDERS, test_connection, load_dotenv_file, get_env_api_key
from modules.progress_tracker import (
    update_progress, compute_mastery, generate_recommendation, get_weak_topics,
)

st.set_page_config(page_title="AI Student Assistant", page_icon="📚", layout="wide")

# Load a local .env file (if present) so a key placed there is picked up
# automatically — no UI steps needed. Real environment variables (set by
# the OS/shell) always take precedence over the .env file's values.
load_dotenv_file(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

# ---------------------------------------------------------------------------
# Styling
# ---------------------------------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"]  { font-family: 'Inter', sans-serif; }

#MainMenu {visibility: hidden;}
footer {visibility: hidden;}

.stApp { background: linear-gradient(180deg, #f8f9ff 0%, #ffffff 260px); }

section[data-testid="stSidebar"] {
    background: #14142b;
    border-right: 1px solid #232345;
}
section[data-testid="stSidebar"] * { color: #e6e6f5 !important; }
section[data-testid="stSidebar"] div[role="radiogroup"] > label {
    padding: 6px 10px;
    border-radius: 10px;
    margin-bottom: 2px;
}
section[data-testid="stSidebar"] div[role="radiogroup"] > label:hover { background: #23234a; }
section[data-testid="stSidebar"] hr { border-color: #2c2c50; }

/* Sidebar buttons (New chat, conversation list, Tools, Settings, Log out):
   Streamlit's button label sits in its own inner element with a default
   color that beats the blanket rule above, leaving light text on the
   button's default light background — i.e. invisible. Style the button
   itself explicitly instead of relying on inheritance. */
section[data-testid="stSidebar"] div.stButton > button {
    background: #1e1e3f !important;
    border: 1px solid #2c2c52 !important;
    color: #e6e6f5 !important;
}
section[data-testid="stSidebar"] div.stButton > button:hover {
    background: #292954 !important;
    border-color: #6C5CE7 !important;
    color: #ffffff !important;
}
section[data-testid="stSidebar"] div.stButton > button * {
    color: inherit !important;
}
section[data-testid="stSidebar"] div.stButton > button[kind="primary"] {
    background: linear-gradient(90deg, #6C5CE7, #8e6cf5) !important;
    border: none !important;
    color: #ffffff !important;
}

.hero-title {
    font-size: 2.3rem;
    font-weight: 800;
    color: #6C5CE7;
    background: linear-gradient(90deg, #6C5CE7, #a06cf5 60%, #ff6fa5);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.2rem;
}
.hero-subtitle { font-size: 1.02rem; color: #5b5b73 !important; margin-bottom: 1.4rem; }

.feature-card {
    background: #ffffff;
    border: 1px solid #ececf6;
    border-radius: 16px;
    padding: 20px 20px 16px 20px;
    box-shadow: 0 2px 10px rgba(80,60,180,0.05);
    height: 100%;
}
.feature-card h4 { margin: 6px 0 4px 0; font-size: 1.05rem; color: #1a1a2e !important; font-weight: 700; }
.feature-card p { color: #6b6b80 !important; font-size: 0.88rem; margin-bottom: 0; }
.feature-icon { font-size: 1.6rem; }

.pill {
    display: inline-block; padding: 3px 12px; border-radius: 999px;
    background: #eef0ff; color: #4b3fc9 !important; font-size: 0.78rem;
    font-weight: 600; margin-right: 6px;
}

.conv-item {
    padding: 7px 10px; border-radius: 8px; font-size: 0.85rem;
    margin-bottom: 2px; cursor: pointer;
}

div.stButton > button { border-radius: 10px; font-weight: 600; }
div.stButton > button[kind="primary"] {
    background: linear-gradient(90deg, #6C5CE7, #8e6cf5); border: none;
}

h1, h2, h3, h4, h5, .stMarkdown h1, .stMarkdown h2, .stMarkdown h3, .stMarkdown h4 {
    color: #1a1a2e !important;
}
p, li, span, label, div[data-testid="stMarkdownContainer"] { color: #2b2b3d; }

hr { margin: 0.6rem 0 1.2rem 0; }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
def init_state():
    defaults = {
        "authenticated": False,
        "username": None,
        "display_name": None,
        "auth_mode": "login",       # "login" or "register"
        "user_data_loaded": False,

        "chunks": None,
        "store": None,
        "doc_name": None,

        "conversations": [],        # list of {"id","title","messages","last_topic"}
        "active_conv_id": None,

        "progress": {},
        "active_quiz": None,
        "quiz_answers": {},

        "page": "chat",
        "llm_provider": list(PROVIDERS.keys())[0],
        "llm_api_key": "",
        "llm_model": "",  # empty = use provider's default_model
        "remember_key": False,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


init_state()


def full_logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    init_state()


def load_user_data():
    """Called once right after a successful login, to restore this
    user's saved document, conversations, progress, and settings."""
    username = st.session_state.username

    conversations = storage.load_conversations(username)
    st.session_state.conversations = conversations
    st.session_state.active_conv_id = conversations[0]["id"] if conversations else None

    st.session_state.progress = storage.load_progress(username)

    settings = storage.load_settings(username)
    if settings.get("provider") in PROVIDERS:
        st.session_state.llm_provider = settings["provider"]
    if settings.get("model"):
        st.session_state.llm_model = settings["model"]
    if settings.get("remember_key") and settings.get("api_key"):
        st.session_state.llm_api_key = settings["api_key"]
        st.session_state.remember_key = True
    else:
        # No key saved to this account yet — fall back to a .env file /
        # real environment variable for the selected provider, if present.
        env_key = get_env_api_key(st.session_state.llm_provider)
        if env_key:
            st.session_state.llm_api_key = env_key
            st.session_state.remember_key = False  # sourced from .env, not the account file

    doc_name, chunks = storage.load_document(username)
    if chunks:
        with st.spinner("Restoring your saved notes..."):
            store = EmbeddingStore()
            store.build(chunks)
            st.session_state.chunks = chunks
            st.session_state.store = store
            st.session_state.doc_name = doc_name

    st.session_state.user_data_loaded = True


if st.session_state.authenticated and not st.session_state.user_data_loaded:
    load_user_data()


def get_context_text(retrieved):
    """retrieved: list of (chunk, score) -> concatenated chunk text, with
    near-duplicate sentences removed (adjacent chunks overlap by design for
    retrieval quality, which otherwise causes repeated sentences here)."""
    seen = set()
    unique_sentences = []
    for c, _ in retrieved:
        for sent in sent_tokenize(c["text"]):
            key = sent[:60].lower()
            if key not in seen:
                seen.add(key)
                unique_sentences.append(sent)
    return " ".join(unique_sentences)


def get_active_conversation():
    for conv in st.session_state.conversations:
        if conv["id"] == st.session_state.active_conv_id:
            return conv
    return None


def create_new_conversation():
    conv = {"id": str(uuid.uuid4()), "title": "New chat", "messages": [], "last_topic": None}
    st.session_state.conversations.insert(0, conv)
    st.session_state.active_conv_id = conv["id"]
    storage.save_conversations(st.session_state.username, st.session_state.conversations)
    return conv


def persist_conversations():
    storage.save_conversations(st.session_state.username, st.session_state.conversations)


# ---------------------------------------------------------------------------
# PAGE: Auth (login / register)
# ---------------------------------------------------------------------------
def render_auth():
    left, mid, right = st.columns([1, 1.3, 1])
    with mid:
        st.markdown('<div class="hero-title">📚 AI Student Assistant</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="hero-subtitle">Your notes, turned into a chat companion. '
            'Create a free local account to save your document, chats, and progress.</div>',
            unsafe_allow_html=True,
        )

        mode = st.session_state.auth_mode
        with st.container(border=True):
            if mode == "login":
                st.markdown("#### Log in")
                username = st.text_input("Username", key="login_username")
                password = st.text_input("Password", type="password", key="login_password")
                if st.button("Log in", type="primary", use_container_width=True):
                    if not username or not password:
                        st.error("Please enter both a username and password.")
                    else:
                        ok, result = auth.authenticate(username.strip().lower(), password)
                        if ok:
                            st.session_state.authenticated = True
                            st.session_state.username = username.strip().lower()
                            st.session_state.display_name = result
                            st.session_state.user_data_loaded = False
                            st.rerun()
                        else:
                            st.error(result)
                st.caption("Don't have an account?")
                if st.button("Create one instead", use_container_width=True):
                    st.session_state.auth_mode = "register"
                    st.rerun()
            else:
                st.markdown("#### Create your account")
                username = st.text_input("Choose a username", key="reg_username")
                display_name = st.text_input("Display name (optional)", key="reg_display")
                password = st.text_input("Choose a password", type="password", key="reg_password")
                password2 = st.text_input("Confirm password", type="password", key="reg_password2")
                if st.button("Create account", type="primary", use_container_width=True):
                    if password != password2:
                        st.error("Passwords don't match.")
                    else:
                        ok, msg = auth.register_user(username.strip().lower() if username else "", password, display_name)
                        if ok:
                            st.success(msg + " You can log in now.")
                            st.session_state.auth_mode = "login"
                            st.rerun()
                        else:
                            st.error(msg)
                st.caption("Already have an account?")
                if st.button("Log in instead", use_container_width=True):
                    st.session_state.auth_mode = "login"
                    st.rerun()

        st.caption(
            "🔒 This runs entirely on your own machine — accounts and passwords are stored "
            "locally (salted + hashed) in this project's `data/` folder and never leave it."
        )


# ---------------------------------------------------------------------------
# PAGE: Upload gate (shown once logged in, until a document is loaded)
# ---------------------------------------------------------------------------
def process_upload(uploaded_file):
    with st.spinner("Extracting text and building semantic index..."):
        try:
            file_bytes = uploaded_file.read()
            pages = extract_document(uploaded_file.name, file_bytes)
            chunks = chunk_text(pages)
            if not chunks:
                st.error("Couldn't extract readable text from this file. Try another file.")
                return
            store = EmbeddingStore()
            store.build(chunks)
            st.session_state.chunks = chunks
            st.session_state.store = store
            st.session_state.doc_name = uploaded_file.name
            st.session_state.conversations = []
            st.session_state.active_conv_id = None
            st.session_state.progress = {}
            st.session_state.active_quiz = None

            storage.save_document(st.session_state.username, uploaded_file.name, chunks)
            storage.save_conversations(st.session_state.username, [])
            storage.save_progress(st.session_state.username, {})

            st.success(f"Indexed {len(chunks)} chunks from '{uploaded_file.name}'.")
            st.session_state.page = "chat"
            st.rerun()
        except Exception as e:
            st.error(f"Error processing file: {e}")


def render_upload_gate():
    left, mid, right = st.columns([1, 3, 1])
    with mid:
        st.markdown(
            f'<div class="hero-title">Welcome, {st.session_state.display_name} 👋</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div class="hero-subtitle">Upload a PDF, DOCX, or TXT file of your study material to get '
            'started. It\'s saved to your account, so you won\'t need to re-upload it next time.</div>',
            unsafe_allow_html=True,
        )
        uploaded_file = st.file_uploader(
            "Upload your study material", type=["pdf", "docx", "txt"], label_visibility="collapsed"
        )
        if uploaded_file is not None:
            process_upload(uploaded_file)

        st.write("")
        st.markdown("#### What you'll get")
        cards = [
            ("💬", "Chat with your notes", "A ChatGPT-style conversation, grounded in what you uploaded."),
            ("🎓", "Explain Mode", "Normal, simple, exam, or example explanations on demand."),
            ("📝", "Summarizer", "Quick revision bullets, standard summaries, or exam notes."),
            ("🧠", "Quiz + Grading", "MCQ / True-False / Short Answer, auto-graded, topic-tagged."),
            ("⚖️", "Compare Mode", "'Difference between X and Y' → a structured table."),
            ("📊", "Progress Tracking", "Per-topic mastery and personalized revision tips."),
        ]
        cols = st.columns(3)
        for i, (icon, title, desc) in enumerate(cards):
            with cols[i % 3]:
                st.markdown(
                    f'<div class="feature-card"><div class="feature-icon">{icon}</div>'
                    f'<h4>{title}</h4><p>{desc}</p></div>',
                    unsafe_allow_html=True,
                )
                st.write("")


# ---------------------------------------------------------------------------
# Sidebar (only rendered once authenticated + a document is loaded)
# ---------------------------------------------------------------------------
TOOL_PAGES = [
    ("explain", "🎓 Explain Mode"),
    ("summary", "📝 Summarizer"),
    ("quiz", "🧠 Quiz"),
    ("compare", "⚖️ Compare"),
    ("progress", "📊 Progress"),
]


def render_sidebar():
    with st.sidebar:
        st.markdown("### 📚 AI Student Assistant")
        st.caption(f"👤 {st.session_state.display_name}")
        st.markdown("---")

        if st.button("➕ New chat", use_container_width=True):
            create_new_conversation()
            st.session_state.page = "chat"
            st.rerun()

        conversations = st.session_state.conversations
        if conversations:
            st.caption("RECENT CHATS")
            for conv in conversations[:12]:
                is_active = conv["id"] == st.session_state.active_conv_id and st.session_state.page == "chat"
                label = ("🟣 " if is_active else "") + (conv["title"] or "New chat")
                if st.button(label, key=f"conv_{conv['id']}", use_container_width=True):
                    st.session_state.active_conv_id = conv["id"]
                    st.session_state.page = "chat"
                    st.rerun()

        st.markdown("---")
        st.caption("TOOLS")
        for page_key, label in TOOL_PAGES:
            is_active = st.session_state.page == page_key
            display_label = ("🟣 " if is_active else "") + label
            if st.button(display_label, key=f"nav_{page_key}", use_container_width=True):
                st.session_state.page = page_key
                st.rerun()

        st.markdown("---")
        st.caption(f"📄 **{st.session_state.doc_name}**")
        st.caption(f"{len(st.session_state.chunks)} chunks · backend: {st.session_state.store.backend}")
        if st.button("🔄 Change document", use_container_width=True):
            storage.clear_document(st.session_state.username)
            st.session_state.chunks = None
            st.session_state.store = None
            st.session_state.doc_name = None
            st.rerun()

        st.markdown("---")
        is_settings_active = st.session_state.page == "settings"
        settings_label = ("🟣 " if is_settings_active else "") + "⚙️ Settings (API key)"
        if st.button(settings_label, use_container_width=True):
            st.session_state.page = "settings"
            st.rerun()
        if st.button("🚪 Log out", use_container_width=True):
            full_logout()
            st.rerun()

        st.markdown("---")
        st.caption(
            "Built with Python · Streamlit · scikit-learn · sentence-transformers · "
            "NetworkX (TextRank) · a free LLM API for chat"
        )


# ---------------------------------------------------------------------------
# PAGE: Chat (ChatGPT-style, RAG over the student's notes)
# ---------------------------------------------------------------------------
def render_chat():
    conv = get_active_conversation()
    if conv is None:
        conv = create_new_conversation()

    has_key = bool(st.session_state.llm_api_key)
    if has_key:
        st.caption(f"💡 Answering with {st.session_state.llm_provider}, grounded in your notes.")
    else:
        st.caption(
            "⚙️ Offline NLP mode (no API key set) — answers are extracted directly from your notes. "
            "Add a free API key in Settings for more natural, conversational answers."
        )

    for msg in conv["messages"]:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    query = st.chat_input("Ask a question about your notes...")
    if query:
        conv["messages"].append({"role": "user", "content": query})
        with st.chat_message("user"):
            st.write(query)

        if conv["title"] == "New chat":
            conv["title"] = (query[:42] + "…") if len(query) > 42 else query

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                if has_key:
                    result = llm_chat_answer(
                        query, st.session_state.store, conv["messages"][:-1],
                        provider=st.session_state.llm_provider,
                        api_key=st.session_state.llm_api_key,
                        model=st.session_state.llm_model or None,
                        last_topic=conv.get("last_topic"),
                        doc_title=st.session_state.doc_name,
                    )
                    if result.get("fallback_used"):
                        st.caption(f"⚠️ Couldn't reach {st.session_state.llm_provider} — showing an "
                                   f"offline extractive answer instead.")
                        with st.expander("Why did this fail? (error detail)"):
                            st.code(result.get("fallback_error") or "Unknown error", language=None)
                else:
                    result = answer_question(
                        query, st.session_state.store,
                        last_topic=conv.get("last_topic"),
                        doc_title=st.session_state.doc_name,
                    )
                conv["last_topic"] = result.get("new_topic") or conv.get("last_topic")
                if result.get("was_followup"):
                    st.caption(f"🔗 Understood as a follow-up about: *{conv['last_topic']}*")
                st.write(result["answer"])

        conv["messages"].append({"role": "assistant", "content": result["answer"]})
        persist_conversations()


# ---------------------------------------------------------------------------
# PAGE: Explain Mode
# ---------------------------------------------------------------------------
def render_explain():
    st.subheader("🎓 Explain Like I'm a Student — Adaptive Explanation Mode")
    conv = get_active_conversation()
    default_topic = (conv.get("last_topic") if conv else "") or ""

    col1, col2 = st.columns([3, 2])
    with col1:
        explain_query = st.text_input("Which topic should I explain?", value=default_topic, key="explain_topic_input")
    with col2:
        explain_mode = st.selectbox(
            "Mode",
            ["Explain normally", "Explain simply", "Explain with an example", "Explain for exam", "Explain in detail"],
        )

    if st.button("Explain", type="primary") and explain_query.strip():
        retrieved = st.session_state.store.search(explain_query, top_k=4)
        if not retrieved:
            st.error(f"Couldn't find '{explain_query}' in your uploaded notes.")
        else:
            combined = get_context_text(retrieved)
            mode_map = {
                "Explain normally": "normal", "Explain simply": "simple",
                "Explain with an example": "example", "Explain for exam": "exam",
                "Explain in detail": "detail",
            }
            result = explain(combined, explain_query, mode_map[explain_mode])

            st.markdown("---")
            if result["type"] == "text":
                st.markdown(result["content"])
            else:
                d = result["content"]
                st.markdown(f"### 📘 Exam-Mode Explanation: {d['topic']}")
                st.markdown(f"**Definition:** {d['definition']}")
                st.markdown("**Main Points:**")
                for p in d["main_points"]:
                    st.markdown(f"- {p}")
                st.markdown("**Working:**")
                for w in d["working"]:
                    st.markdown(f"- {w}")
                st.markdown(f"**Example:** {d['example']}")
                st.markdown("**Advantages:**")
                for a in d["advantages"]:
                    st.markdown(f"- {a}")
                st.markdown("**Disadvantages:**")
                for dd in d["disadvantages"]:
                    st.markdown(f"- {dd}")
                st.markdown(f"**Keywords:** {', '.join(d['keywords'])}")

            pages = sorted(set(c.get("page") for c, _ in retrieved if c.get("page") is not None))
            if pages:
                st.caption(f"Source: page/section {', '.join(str(p) for p in pages)}")


# ---------------------------------------------------------------------------
# PAGE: Summarizer
# ---------------------------------------------------------------------------
def render_summary():
    st.subheader("📝 Intelligent Notes Summarizer")
    scope = st.radio("Summarize:", ["Entire document", "A specific topic/section"], horizontal=True)
    topic_for_summary = None
    conv = get_active_conversation()
    if scope == "A specific topic/section":
        topic_for_summary = st.text_input(
            "Topic/section to summarize", value=(conv.get("last_topic") if conv else "") or ""
        )

    summary_format = st.selectbox("Summary format", ["Quick Revision", "Standard Summary", "Exam Notes"])

    if st.button("Summarize", type="primary"):
        text_to_summarize = None
        label = None
        if scope == "Entire document":
            text_to_summarize = " ".join(c["text"] for c in st.session_state.chunks)
            label = st.session_state.doc_name
        else:
            if not topic_for_summary.strip():
                st.error("Please enter a topic.")
            else:
                retrieved = st.session_state.store.search(topic_for_summary, top_k=6)
                if not retrieved:
                    st.error(f"Couldn't find '{topic_for_summary}' in your notes.")
                else:
                    text_to_summarize = get_context_text(retrieved)
                    label = topic_for_summary

        if text_to_summarize:
            mode_map = {"Quick Revision": "quick", "Standard Summary": "standard", "Exam Notes": "exam"}
            result = summarize(text_to_summarize, mode_map[summary_format], topic=label)

            st.markdown("---")
            st.markdown(f"### {summary_format} — {label}")
            if result["type"] == "text":
                st.markdown(result["content"])
            else:
                d = result["content"]
                st.markdown(f"**Definition:** {d['definition']}")
                st.markdown("**Key Concepts:**")
                for k in d["key_concepts"]:
                    st.markdown(f"- {k}")
                st.markdown("**Working:**")
                for w in d["working"]:
                    st.markdown(f"- {w}")
                st.markdown("**Advantages:**")
                for a in d["advantages"]:
                    st.markdown(f"- {a}")
                st.markdown("**Disadvantages:**")
                for dd in d["disadvantages"]:
                    st.markdown(f"- {dd}")
                st.markdown("**Examples:**")
                for ex in d["examples"]:
                    st.markdown(f"- {ex}")
                st.markdown(f"**Keywords:** {', '.join(d['keywords'])}")


# ---------------------------------------------------------------------------
# PAGE: Quiz
# ---------------------------------------------------------------------------
def render_quiz():
    st.subheader("🧠 AI Quiz Generator + Intelligent Evaluation")
    if st.session_state.active_quiz is None:
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            quiz_topic = st.text_input("Topic (optional — blank = whole document)", value="")
        with c2:
            num_q = st.selectbox("Number of questions", [5, 10, 15], index=0)
        with c3:
            difficulty = st.selectbox("Difficulty", ["Easy", "Medium", "Hard"], index=1)
        with c4:
            qtype = st.selectbox("Question type", ["MCQ", "True/False", "Short Answer", "Mixed"])

        if st.button("Generate Quiz", type="primary"):
            if quiz_topic.strip():
                retrieved = st.session_state.store.search(quiz_topic, top_k=10)
                relevant_chunks = [c for c, _ in retrieved] or st.session_state.chunks
                topic_label = quiz_topic
            else:
                relevant_chunks = st.session_state.chunks
                topic_label = None

            questions = generate_quiz(relevant_chunks, topic_label, num_questions=num_q,
                                       difficulty=difficulty, qtype=qtype)
            if not questions:
                st.error("Couldn't generate questions from this material/topic. Try a broader topic or different notes.")
            else:
                st.session_state.active_quiz = questions
                st.session_state.quiz_answers = {}
                st.rerun()
    else:
        questions = st.session_state.active_quiz
        st.markdown(f"**{len(questions)} questions generated.** Answer below, then submit.")

        with st.form("quiz_form"):
            for i, q in enumerate(questions):
                st.markdown(f"**Q{i+1}. [{q['type']} · {q['difficulty']}] {q['question']}**")
                if q["type"] == "MCQ":
                    choice = st.radio(f"q{i}_options", q["options"], key=f"q_{i}", label_visibility="collapsed")
                    st.session_state.quiz_answers[i] = q["options"].index(choice)
                elif q["type"] == "True/False":
                    choice = st.radio(f"q{i}_tf", ["True", "False"], key=f"q_{i}", label_visibility="collapsed")
                    st.session_state.quiz_answers[i] = (choice == "True")
                else:
                    ans = st.text_area("Your answer", key=f"q_{i}", label_visibility="collapsed")
                    st.session_state.quiz_answers[i] = ans
                st.divider()

            submitted = st.form_submit_button("Submit Quiz", type="primary")

        if submitted:
            responses = [st.session_state.quiz_answers.get(i) for i in range(len(questions))]
            score, total, per_question, topic_results = grade_quiz(questions, responses)
            accuracy = round(100 * score / total) if total else 0

            st.markdown(f"## Score: {score}/{total}  ·  Accuracy: {accuracy}%")

            mastery_this_round = compute_mastery(topic_results)
            strong = [t for t, p in mastery_this_round.items() if p >= 70]
            weak = [t for t, p in mastery_this_round.items() if p < 70]

            cols = st.columns(2)
            with cols[0]:
                st.markdown("**Strong Topics ✓**")
                for t in strong:
                    st.markdown(f"- ✓ {t}")
                if not strong:
                    st.caption("None yet this round.")
            with cols[1]:
                st.markdown("**Needs Revision ⚠**")
                for t in weak:
                    st.markdown(f"- ⚠ {t}")
                if not weak:
                    st.caption("None — nice work!")

            with st.expander("Review answers"):
                for i, r in enumerate(per_question):
                    icon = "✅" if r["correct"] else "❌"
                    st.markdown(f"{icon} **Q{i+1}.** {r['question']['question']}")
                    st.caption(r["detail"])

            st.session_state.progress = update_progress(st.session_state.progress, topic_results)
            storage.save_progress(st.session_state.username, st.session_state.progress)

            if weak:
                st.info(
                    f"You seem to need more practice with **{weak[0]}**. "
                    f"Head to Explain Mode or generate another quiz on '{weak[0]}'."
                )

            if st.button("Start a new quiz"):
                st.session_state.active_quiz = None
                st.session_state.quiz_answers = {}
                st.rerun()


# ---------------------------------------------------------------------------
# PAGE: Compare
# ---------------------------------------------------------------------------
def render_compare():
    st.subheader("⚖️ Smart Comparison Mode")
    st.caption('Try: "Difference between stemming and lemmatization", "stemming vs lemmatization", '
               'or just "stemming and lemmatization".')
    compare_query = st.text_input("Comparison question or two terms", key="compare_input")

    if st.button("Compare", type="primary") and compare_query.strip():
        detected = detect_comparison(compare_query)
        if not detected:
            if " vs " in compare_query.lower():
                parts = compare_query.lower().split(" vs ")
                detected = (parts[0].strip(), parts[1].strip())
            elif "," in compare_query:
                parts = compare_query.split(",")
                detected = (parts[0].strip(), parts[1].strip())
            elif " and " in compare_query.lower():
                parts = compare_query.lower().split(" and ")
                if len(parts) == 2:
                    detected = (parts[0].strip(), parts[1].strip())

        if not detected:
            st.error("Couldn't detect two terms to compare. Try: 'difference between X and Y'.")
        else:
            term_a, term_b = detected
            result = build_comparison(term_a, term_b, st.session_state.store)

            st.markdown("---")
            st.markdown(f"### {result['term_a']} vs {result['term_b']}")
            table_md = "| Feature | " + result["term_a"] + " | " + result["term_b"] + " |\n|---|---|---|\n"
            for row in result["rows"]:
                a = row["a"].replace("|", "/")
                b = row["b"].replace("|", "/")
                table_md += f"| {row['feature']} | {a} | {b} |\n"
            st.markdown(table_md)

            if not result["found"]:
                st.warning("One or both terms weren't clearly found in your uploaded notes — some rows may be incomplete.")


# ---------------------------------------------------------------------------
# PAGE: Progress
# ---------------------------------------------------------------------------
def render_progress():
    st.subheader("📊 Personalized Revision Recommendation")
    if not st.session_state.progress:
        st.info("Take a quiz first (see the 🧠 Quiz page) to build your progress record.")
    else:
        mastery = compute_mastery(st.session_state.progress)
        st.markdown("### Your Study Progress")
        for topic, pct in sorted(mastery.items(), key=lambda x: -x[1]):
            st.write(f"**{topic}** — {pct}%")
            st.progress(pct / 100)

        st.markdown("### Recommendation")
        st.markdown(generate_recommendation(mastery))

        weak = get_weak_topics(mastery)
        if weak:
            st.markdown("### Quick Actions")
            for t in weak[:3]:
                c1, c2 = st.columns(2)
                with c1:
                    if st.button(f"📖 Explain '{t}'", key=f"explain_weak_{t}"):
                        st.session_state.page = "explain"
                        conv = get_active_conversation()
                        if conv:
                            conv["last_topic"] = t
                        st.rerun()
                with c2:
                    if st.button(f"🧠 Quiz on '{t}'", key=f"quiz_weak_{t}"):
                        st.session_state.page = "quiz"
                        st.session_state.active_quiz = None
                        st.rerun()

        if st.button("Reset progress record"):
            st.session_state.progress = {}
            storage.save_progress(st.session_state.username, {})
            st.rerun()


# ---------------------------------------------------------------------------
# PAGE: Settings (free LLM API key)
# ---------------------------------------------------------------------------
def render_settings():
    st.subheader("⚙️ Chat Settings — Free LLM API")
    st.write(
        "The Chat page can answer using a free LLM API to phrase responses naturally "
        "(the retrieval that grounds it in your notes is always done locally with real "
        "NLP, regardless of this setting). Without a key, Chat automatically falls back "
        "to a fully offline, extractive answer — nothing breaks either way."
    )

    provider = st.selectbox("Provider", list(PROVIDERS.keys()),
                             index=list(PROVIDERS.keys()).index(st.session_state.llm_provider))
    cfg = PROVIDERS[provider]
    st.caption(f"{cfg['notes']}  ·  [Get a free API key here]({cfg['signup_url']})")

    if st.session_state.llm_api_key and not st.session_state.remember_key:
        st.caption(
            f"🔑 Currently using a key from your `.env` file (`{cfg['env_key']}`). "
            "Saving below with 'Remember' checked will store an account-specific key instead."
        )

    api_key = st.text_input("API key", value=st.session_state.llm_api_key, type="password")

    model = st.text_input(
        "Model",
        value=st.session_state.llm_model or cfg["default_model"],
        help="If you get a '404: model does not exist' error, the provider has likely "
             "renamed or retired this model. Check the provider's current model list "
             "(linked above) and paste the current name here.",
    )
    st.caption(f"Default: `{cfg['default_model']}`")

    remember = st.checkbox(
        "Remember this key on this device (stored locally in a plain JSON file under `data/`)",
        value=st.session_state.remember_key,
    )

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Save", type="primary", use_container_width=True):
            st.session_state.llm_provider = provider
            st.session_state.llm_api_key = api_key
            st.session_state.llm_model = model.strip()
            st.session_state.remember_key = remember
            storage.save_settings(st.session_state.username, {
                "provider": provider,
                "api_key": api_key if remember else None,
                "model": model.strip(),
                "remember_key": remember,
            })
            st.success("Settings saved.")
    with col2:
        if st.button("Test connection", use_container_width=True):
            if not api_key:
                st.error("Enter an API key first.")
            else:
                with st.spinner("Contacting provider..."):
                    ok, msg = test_connection(provider, api_key, model=model.strip() or None)
                if ok:
                    st.success(f"Connected! Model replied: {msg}")
                else:
                    st.error(f"Couldn't connect: {msg}")

    if st.session_state.llm_api_key and st.button("Remove saved key"):
        st.session_state.llm_api_key = ""
        st.session_state.remember_key = False
        storage.save_settings(st.session_state.username, {
            "provider": st.session_state.llm_provider, "api_key": None,
            "model": st.session_state.llm_model, "remember_key": False,
        })
        st.rerun()


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------
if not st.session_state.authenticated:
    render_auth()
elif st.session_state.store is None:
    render_upload_gate()
else:
    render_sidebar()
    page = st.session_state.page
    router = {
        "chat": render_chat,
        "explain": render_explain,
        "summary": render_summary,
        "quiz": render_quiz,
        "compare": render_compare,
        "progress": render_progress,
        "settings": render_settings,
    }
    router.get(page, render_chat)()
