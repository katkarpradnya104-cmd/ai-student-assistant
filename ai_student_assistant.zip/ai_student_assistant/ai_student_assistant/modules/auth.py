"""
auth.py
-------
Lightweight local authentication for the AI Student Assistant.

This is a self-contained, file-based (JSON) user store intended for a
single-machine / mini-project deployment — not a production auth system.
Passwords are never stored in plaintext: they're salted and hashed with
PBKDF2-HMAC-SHA256 (stdlib `hashlib`, no extra dependency required).

Each user gets their own isolated data (documents, progress, chat) via the
session, keyed by username — see app.py's session-state handling.
"""

import hashlib
import json
import os
import secrets
import time

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DATA_DIR = os.path.join(_BASE_DIR, "data")
USERS_FILE = os.path.join(_DATA_DIR, "users.json")

_PBKDF2_ITERATIONS = 200_000


def _ensure_store():
    os.makedirs(_DATA_DIR, exist_ok=True)
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w") as f:
            json.dump({}, f)


def _load_users():
    _ensure_store()
    try:
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return {}


def _save_users(users: dict):
    _ensure_store()
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=2)


def _hash_password(password: str, salt_hex: str = None):
    if salt_hex is None:
        salt_hex = secrets.token_hex(16)
    pwd_hash = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), _PBKDF2_ITERATIONS
    ).hex()
    return salt_hex, pwd_hash


def register_user(username: str, password: str, display_name: str = None):
    """Returns (success: bool, message: str)."""
    username = (username or "").strip().lower()
    if not username or not password:
        return False, "Username and password are required."
    if len(username) < 3:
        return False, "Username must be at least 3 characters."
    if len(password) < 4:
        return False, "Password must be at least 4 characters."

    users = _load_users()
    if username in users:
        return False, "That username is already taken."

    salt_hex, pwd_hash = _hash_password(password)
    users[username] = {
        "display_name": (display_name or username).strip(),
        "salt": salt_hex,
        "hash": pwd_hash,
        "created_at": time.time(),
    }
    _save_users(users)
    return True, "Account created! You can log in now."


def authenticate(username: str, password: str):
    """Returns (success: bool, display_name_or_error: str)."""
    username = (username or "").strip().lower()
    users = _load_users()
    user = users.get(username)
    if not user:
        return False, "No account with that username."

    _, pwd_hash = _hash_password(password, salt_hex=user["salt"])
    if not secrets.compare_digest(pwd_hash, user["hash"]):
        return False, "Incorrect password."

    return True, user.get("display_name", username)
