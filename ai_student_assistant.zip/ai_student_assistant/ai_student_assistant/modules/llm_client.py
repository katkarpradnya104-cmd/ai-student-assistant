"""
llm_client.py
-------------
Thin, provider-agnostic wrapper for calling a free-tier, OpenAI-compatible
chat completion API. This is used only to turn the retrieval-grounded
context pulled from the student's own notes into a natural, conversational
answer — the "LLM/API only where useful for generation" part of the
original spec — while retrieval, chunking, and every other feature stay
pure NLP (see qa_engine.py, explain_engine.py, summarizer.py, etc.).

Supported providers (both offer a genuinely free tier, no credit card):
  - Groq       https://console.groq.com/keys   (very fast; Llama 3.3 70B)
  - OpenRouter https://openrouter.ai/keys       (many ':free' models)

Both expose an OpenAI-compatible /chat/completions endpoint, so the same
request/response handling works for either — swapping providers is just a
different base URL, default model, and API key.
"""

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

_session = requests.Session()
_retry = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
_session.mount("https://", HTTPAdapter(max_retries=_retry))

PROVIDERS = {
    "Groq (GPT-OSS 120B) — recommended": {
        "base_url": "https://api.groq.com/openai/v1/chat/completions",
        "default_model": "openai/gpt-oss-120b",
        "signup_url": "https://console.groq.com/keys",
        "notes": "Free, no credit card required. Fastest option (custom LPU hardware). "
                 "Note: Groq retired the older Llama 3.3 70B / 3.1 8B models on Aug 16, 2026 — "
                 "this now points at their GPT-OSS replacement models.",
        "env_key": "GROQ_API_KEY",
    },
    "OpenRouter (free models)": {
        "base_url": "https://openrouter.ai/api/v1/chat/completions",
        "default_model": "meta-llama/llama-3.3-70b-instruct:free",
        "signup_url": "https://openrouter.ai/keys",
        "notes": "Free tier with rate limits; wide model choice.",
        "env_key": "OPENROUTER_API_KEY",
    },
}


def load_dotenv_file(path: str):
    """Minimal, dependency-free .env loader: parses KEY=VALUE lines from the
    given path (if it exists) into os.environ, so a key placed in a local
    .env file is picked up automatically at startup — no code changes or
    UI steps needed. Ignores blank lines and lines starting with '#'.
    Existing environment variables are never overwritten (a real env var
    set by the OS/shell always wins over the .env file)."""
    import os
    if not path or not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


def get_env_api_key(provider: str):
    """Returns the API key for this provider from the environment (populated
    either by a real env var or by load_dotenv_file), or None if not set."""
    import os
    env_key = PROVIDERS.get(provider, {}).get("env_key")
    if not env_key:
        return None
    return os.environ.get(env_key) or None


class LLMError(Exception):
    pass


def call_llm(provider: str, api_key: str, messages: list, model: str = None,
             temperature: float = 0.4, max_tokens: int = 700, timeout: int = 30) -> str:
    """messages: list of {"role": "system"|"user"|"assistant", "content": str}"""
    if provider not in PROVIDERS:
        raise LLMError(f"Unknown provider: {provider}")
    if not api_key:
        raise LLMError("No API key configured. Add one in Settings.")

    cfg = PROVIDERS[provider]
    url = cfg["base_url"]
    model = model or cfg["default_model"]

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    try:
                resp = _session.post(url, headers=headers, json=payload, timeout=(10, timeout))
    except requests.exceptions.RequestException as e:
        raise LLMError(f"Network error contacting {provider}: {e}")

    if resp.status_code != 200:
        try:
            detail = resp.json().get("error", {}).get("message", resp.text[:300])
        except Exception:
            detail = resp.text[:300]
        raise LLMError(f"{provider} returned HTTP {resp.status_code}: {detail}")

    try:
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError) as e:
        raise LLMError(f"Unexpected response shape from {provider}: {e}")


def test_connection(provider: str, api_key: str, model: str = None) -> (bool, str):
    """Quick sanity-check call used by the Settings page."""
    try:
        reply = call_llm(
            provider, api_key,
            [{"role": "user", "content": "Reply with exactly: connection ok"}],
            model=model, max_tokens=20, temperature=0,
        )
        return True, reply
    except LLMError as e:
        return False, str(e)
