"""
intent_classifier.py
---------------------
Classifies a student's free-text request into one of several intents so it
can be automatically routed to the right module, instead of the student
having to manually pick a tab every time.

Approach: a small supervised TF-IDF + Logistic Regression text classifier
trained on a curated seed dataset of example phrasings per intent
(demonstrates the "text classification" NLP concept), backed by a
rule-based keyword/regex layer that overrides the model for
high-confidence, unambiguous patterns (e.g. "Nq MCQs on X" is unmistakably
QUIZ_GENERATION). This hybrid keeps the classifier both explainable and
robust on a tiny training set.
"""

import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

INTENTS = [
    "GENERAL_GREETING",
    "DEFINITION",
    "EXPLANATION",
    "SUMMARIZATION",
    "QUIZ_GENERATION",
    "COMPARISON",
    "REVISION",
    "QUESTION_ANSWERING",
]

# Seed training data: (text, intent)
_SEED_DATA = [
    ("hi", "GENERAL_GREETING"),
    ("hello", "GENERAL_GREETING"),
    ("hey there", "GENERAL_GREETING"),
    ("good morning", "GENERAL_GREETING"),
    ("thanks", "GENERAL_GREETING"),
    ("thank you", "GENERAL_GREETING"),

    ("what is tokenization", "DEFINITION"),
    ("define stemming", "DEFINITION"),
    ("what is an hmm", "DEFINITION"),
    ("what does parsing mean", "DEFINITION"),
    ("meaning of lemmatization", "DEFINITION"),
    ("define named entity recognition", "DEFINITION"),

    ("explain stemming like i'm a beginner", "EXPLANATION"),
    ("explain this in simple words", "EXPLANATION"),
    ("can you explain hmm simply", "EXPLANATION"),
    ("explain with an example", "EXPLANATION"),
    ("explain in detail", "EXPLANATION"),
    ("elaborate on this topic", "EXPLANATION"),
    ("i don't understand this, explain it", "EXPLANATION"),

    ("summarize this chapter", "SUMMARIZATION"),
    ("give me a summary of the document", "SUMMARIZATION"),
    ("quick revision notes please", "SUMMARIZATION"),
    ("summarize parsing section", "SUMMARIZATION"),
    ("give me exam notes for this topic", "SUMMARIZATION"),
    ("shorten this into bullet points", "SUMMARIZATION"),

    ("give me 10 mcqs on hmm", "QUIZ_GENERATION"),
    ("generate a quiz on nlp", "QUIZ_GENERATION"),
    ("test my knowledge on stemming", "QUIZ_GENERATION"),
    ("create 5 true or false questions", "QUIZ_GENERATION"),
    ("quiz me on tokenization", "QUIZ_GENERATION"),
    ("make a hard quiz with 15 questions", "QUIZ_GENERATION"),

    ("difference between stemming and lemmatization", "COMPARISON"),
    ("compare top down and bottom up parsing", "COMPARISON"),
    ("stemming vs lemmatization", "COMPARISON"),
    ("how is hmm different from rule based approach", "COMPARISON"),
    ("what's the difference between nlp and nlu", "COMPARISON"),

    ("what should i revise", "REVISION"),
    ("show my weak topics", "REVISION"),
    ("what is my progress", "REVISION"),
    ("recommend what to study next", "REVISION"),
    ("how am i doing in quizzes", "REVISION"),

    ("what are its advantages", "QUESTION_ANSWERING"),
    ("how does it work", "QUESTION_ANSWERING"),
    ("why do we use this technique", "QUESTION_ANSWERING"),
    ("when is this used", "QUESTION_ANSWERING"),
    ("who introduced this concept", "QUESTION_ANSWERING"),
    ("tell me about the working of hmm", "QUESTION_ANSWERING"),
]

# High-confidence regex overrides (checked before the ML model)
_RULES = [
    (re.compile(r"\b(hi|hello|hey)\b", re.I), "GENERAL_GREETING"),
    (re.compile(r"\b(mcqs?|quiz|questions? on|true[/ ]or[/ ]false|test my)\b", re.I), "QUIZ_GENERATION"),
    (re.compile(r"\b(difference between|compare|vs\.?|versus)\b", re.I), "COMPARISON"),
    (re.compile(r"\b(summar(y|ize|ise)|revision notes|exam notes|bullet points)\b", re.I), "SUMMARIZATION"),
    (re.compile(r"\b(what is|what are)\b(?!\s+(it|its|this|that|these|those|his|her|their)\b)", re.I), "DEFINITION"),
    (re.compile(r"\b(define|meaning of)\b", re.I), "DEFINITION"),
    (re.compile(r"\b(explain|simplify|simple words|elaborate|in detail)\b", re.I), "EXPLANATION"),
    (re.compile(r"\b(weak topics?|my progress|what should i revise|recommend)\b", re.I), "REVISION"),
]


class IntentClassifier:
    def __init__(self):
        texts = [t for t, _ in _SEED_DATA]
        labels = [l for _, l in _SEED_DATA]
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2))
        X = self.vectorizer.fit_transform(texts)
        self.model = LogisticRegression(max_iter=1000)
        self.model.fit(X, labels)

    def classify(self, text: str):
        text = text.strip()
        if not text:
            return "GENERAL_GREETING", 1.0

        # Rule-based override first (fast, explainable, handles edge cases
        # the tiny seed dataset may not generalize to).
        for pattern, intent in _RULES:
            if pattern.search(text):
                return intent, 0.95

        X = self.vectorizer.transform([text])
        probs = self.model.predict_proba(X)[0]
        idx = probs.argmax()
        intent = self.model.classes_[idx]
        confidence = float(probs[idx])

        # If the ML model is unsure, default to question-answering (the
        # safest catch-all — it still runs semantic search over the notes).
        if confidence < 0.30:
            intent = "QUESTION_ANSWERING"
        return intent, confidence


_classifier_singleton = None


def get_classifier():
    global _classifier_singleton
    if _classifier_singleton is None:
        _classifier_singleton = IntentClassifier()
    return _classifier_singleton


def classify_intent(text: str):
    """Convenience function returning (intent, confidence)."""
    return get_classifier().classify(text)
