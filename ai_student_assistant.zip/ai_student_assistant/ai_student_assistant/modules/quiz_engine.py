"""
quiz_engine.py
--------------
AI Quiz Generator + Intelligent Evaluation.

Generates MCQ / True-False / Short-Answer questions *only* from the
uploaded material (no invented facts), scores student attempts, and feeds
per-topic correctness into the progress tracker for weak-topic detection.

Generation strategy (fully local, no external LLM required):
  1. Mine "concept -> defining sentence" pairs from the retrieved chunks
     using simple copula/definition patterns ("X is ...", "X refers to ...").
  2. MCQ: correct option = the real defining sentence (lightly trimmed);
     distractor options = defining sentences of *other* concepts in the
     document, so all options are plausible but only one is factually
     tied to the asked concept.
  3. True/False: take a factual sentence; on ~50% of items, corrupt it
     (negate the verb, or swap in a different concept's detail) to build
     a "False" statement, and record why it's false.
  4. Short Answer: ask "What is <concept>?" and grade the student's free
     text against the expected keyword set using stemmed token overlap.
"""

import random
import re

from modules.preprocessing import sent_tokenize, extract_keywords, preprocess_for_matching

COPULA_RE = re.compile(
    r"^\s*([A-Z][A-Za-z0-9\-\s]{2,40}?)(?:\s*\([A-Za-z0-9]{2,8}\))?\s+(is|are|refers to|is defined as|can be defined as)\s+(.*)$"
)

_GENERIC_TERM_RE = re.compile(
    r"^(an?|the|this|that|these|those)\b.*\b(advantage|disadvantage|benefit|drawback|limitation|"
    r"example|weakness|strength|pro|con)s?\b",
    re.I,
)

NEGATION_SWAPS = [
    (re.compile(r"\bis\b"), "is not"),
    (re.compile(r"\bare\b"), "are not"),
    (re.compile(r"\bcan\b"), "cannot"),
    (re.compile(r"\balways\b"), "never"),
    (re.compile(r"\bincreases\b"), "decreases"),
    (re.compile(r"\bhigher\b"), "lower"),
    (re.compile(r"\bmore\b"), "less"),
]


def _mine_concept_sentences(chunks):
    """Returns list of dicts: {"term": str, "sentence": str, "page": int}"""
    pairs = []
    seen_terms = set()
    for chunk in chunks:
        for sent in sent_tokenize(chunk["text"]):
            m = COPULA_RE.match(sent)
            if m:
                term = m.group(1).strip()
                if _GENERIC_TERM_RE.match(term):
                    continue
                if 2 <= len(term.split()) <= 5 or len(term) <= 30:
                    key = term.lower()
                    if key not in seen_terms and len(sent.split()) >= 5:
                        seen_terms.add(key)
                        pairs.append({"term": term, "sentence": sent, "page": chunk.get("page")})
    return pairs


def _mine_fact_sentences(chunks, min_words=6, max_pool=40):
    """General factual sentences (not necessarily definitions) usable for
    True/False and as filler when concept-pairs are scarce."""
    facts = []
    for chunk in chunks:
        for sent in sent_tokenize(chunk["text"]):
            if min_words <= len(sent.split()) <= 30:
                facts.append({"sentence": sent, "page": chunk.get("page")})
    random.shuffle(facts)
    return facts[:max_pool]


def _corrupt_sentence(sentence: str, alt_term: str = None) -> str:
    for pattern, replacement in NEGATION_SWAPS:
        if pattern.search(sentence):
            return pattern.sub(replacement, sentence, count=1)
    if alt_term:
        # crude corruption: replace the subject with a different concept term
        return re.sub(r"^[A-Z][A-Za-z0-9\-\s]{2,40}?(?=\s+(is|are))", alt_term, sentence, count=1)
    return "This statement is not supported by the notes as written."


def _difficulty_of(sentence: str) -> str:
    n = len(sentence.split())
    if n <= 12:
        return "Easy"
    elif n <= 22:
        return "Medium"
    return "Hard"


def _make_mcq(concept_pairs, idx, topic_label):
    correct = concept_pairs[idx]
    others = [p for i, p in enumerate(concept_pairs) if i != idx]
    random.shuffle(others)
    distractors = others[:3]
    if len(distractors) < 3:
        # not enough distinct concepts; pad with corrupted versions of the correct sentence
        while len(distractors) < 3:
            distractors.append({"term": correct["term"], "sentence": _corrupt_sentence(correct["sentence"])})

    options = [correct["sentence"]] + [d["sentence"] for d in distractors]
    random.shuffle(options)
    correct_index = options.index(correct["sentence"])

    return {
        "type": "MCQ",
        "topic": topic_label or correct["term"],
        "question": f"Which statement best describes \"{correct['term']}\"?",
        "options": options,
        "correct_index": correct_index,
        "explanation": f"\"{correct['term']}\" is described as: {correct['sentence']}",
        "difficulty": _difficulty_of(correct["sentence"]),
        "page": correct.get("page"),
    }


def _make_true_false(fact_pool, concept_pairs, i):
    make_false = random.random() < 0.5
    if fact_pool:
        base = fact_pool[i % len(fact_pool)]
        sentence, page = base["sentence"], base.get("page")
        topic_guess = extract_keywords(sentence, top_n=1)
        topic_label = topic_guess[0] if topic_guess else "General"
    elif concept_pairs:
        base = concept_pairs[i % len(concept_pairs)]
        sentence, page = base["sentence"], base.get("page")
        topic_label = base["term"]
    else:
        sentence, page, topic_label = "No content available.", None, "General"

    if make_false:
        alt_term = None
        if concept_pairs:
            alt_term = random.choice(concept_pairs)["term"]
        statement = _corrupt_sentence(sentence, alt_term=alt_term)
        answer = False
        explanation = f"This is False. According to your notes: {sentence}"
    else:
        statement = sentence
        answer = True
        explanation = f"This is True, as stated in your notes: {sentence}"

    return {
        "type": "True/False",
        "topic": topic_label,
        "question": statement,
        "correct_answer": answer,
        "explanation": explanation,
        "difficulty": _difficulty_of(statement),
        "page": page,
    }


def _make_short_answer(concept_pairs, idx):
    concept = concept_pairs[idx]
    expected_tokens = set(preprocess_for_matching(concept["sentence"]))
    return {
        "type": "Short Answer",
        "topic": concept["term"],
        "question": f"What is {concept['term']}? (Explain briefly in your own words.)",
        "expected_sentence": concept["sentence"],
        "expected_tokens": expected_tokens,
        "difficulty": _difficulty_of(concept["sentence"]),
        "page": concept.get("page"),
    }


def generate_quiz(chunks, topic_label, num_questions=5, difficulty="Medium", qtype="MCQ"):
    """
    chunks: relevant chunk dicts (already filtered/retrieved for the chosen topic,
            or all chunks if no topic filter was applied)
    qtype: "MCQ" | "True/False" | "Short Answer" | "Mixed"
    """
    concept_pairs = _mine_concept_sentences(chunks)
    fact_pool = _mine_fact_sentences(chunks)

    if not concept_pairs and not fact_pool:
        return []

    random.shuffle(concept_pairs)

    questions = []
    type_cycle = (
        ["MCQ", "True/False", "Short Answer"] if qtype == "Mixed" else [qtype]
    )

    i = 0
    attempts = 0
    max_attempts = num_questions * 6 + 10
    while len(questions) < num_questions and attempts < max_attempts:
        attempts += 1
        current_type = type_cycle[i % len(type_cycle)]
        i += 1

        if current_type == "MCQ":
            if len(concept_pairs) >= 1:
                idx = (len(questions)) % len(concept_pairs)
                q = _make_mcq(concept_pairs, idx, topic_label)
                questions.append(q)
            elif fact_pool:
                current_type = "True/False"
            else:
                continue

        if current_type == "True/False":
            q = _make_true_false(fact_pool, concept_pairs, len(questions))
            questions.append(q)

        elif current_type == "Short Answer":
            if concept_pairs:
                idx = len(questions) % len(concept_pairs)
                q = _make_short_answer(concept_pairs, idx)
                questions.append(q)
            elif fact_pool:
                q = _make_true_false(fact_pool, concept_pairs, len(questions))
                questions.append(q)

    # crude difficulty filter/relabel bias: if user asked Easy/Hard specifically,
    # sort so those difficulties appear first (we don't drop questions since pools are small)
    if difficulty in ("Easy", "Hard"):
        questions.sort(key=lambda q: 0 if q["difficulty"] == difficulty else 1)

    return questions[:num_questions]


def grade_short_answer(student_answer: str, expected_tokens: set, threshold: float = 0.35):
    student_tokens = set(preprocess_for_matching(student_answer))
    if not expected_tokens:
        return False, 0.0
    overlap = len(student_tokens & expected_tokens)
    ratio = overlap / max(1, len(expected_tokens))
    return ratio >= threshold, round(ratio, 2)


def grade_quiz(questions, responses):
    """
    responses: list aligned with questions; for MCQ -> selected option index,
               for True/False -> bool, for Short Answer -> str
    Returns: (score, total, per_question_results, topic_results)
    topic_results: {topic: {"correct": n, "total": n}}
    """
    total = len(questions)
    score = 0
    per_question = []
    topic_results = {}

    for q, resp in zip(questions, responses):
        topic = q.get("topic", "General")
        topic_results.setdefault(topic, {"correct": 0, "total": 0})
        topic_results[topic]["total"] += 1

        is_correct = False
        detail = ""

        if q["type"] == "MCQ":
            is_correct = (resp == q["correct_index"])
            detail = q["explanation"]
        elif q["type"] == "True/False":
            is_correct = (resp == q["correct_answer"])
            detail = q["explanation"]
        elif q["type"] == "Short Answer":
            is_correct, ratio = grade_short_answer(resp or "", q["expected_tokens"])
            detail = f"Expected idea: {q['expected_sentence']} (keyword overlap: {ratio})"

        if is_correct:
            score += 1
            topic_results[topic]["correct"] += 1

        per_question.append({"question": q, "response": resp, "correct": is_correct, "detail": detail})

    return score, total, per_question, topic_results
