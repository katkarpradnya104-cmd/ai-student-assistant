"""
progress_tracker.py
--------------------
Personalized Revision Recommendation.

Maintains a simple, transparent (non-ML) score-based performance record per
topic across quiz attempts, detects weak topics, and produces plain-English
revision recommendations. Designed to sit on top of Streamlit's
`st.session_state` so it persists for the duration of a session.
"""

WEAK_THRESHOLD = 60  # percent
STRONG_THRESHOLD = 80


def update_progress(progress: dict, topic_results: dict):
    """progress: {topic: {"correct": int, "total": int}} accumulated across attempts.
    topic_results: same shape, from the most recent quiz attempt.
    Mutates and returns `progress`.
    """
    for topic, result in topic_results.items():
        if topic not in progress:
            progress[topic] = {"correct": 0, "total": 0}
        progress[topic]["correct"] += result["correct"]
        progress[topic]["total"] += result["total"]
    return progress


def compute_mastery(progress: dict):
    """Returns {topic: percent_mastery (0-100)}"""
    mastery = {}
    for topic, r in progress.items():
        total = r.get("total", 0)
        if total == 0:
            mastery[topic] = 0
        else:
            mastery[topic] = round(100 * r["correct"] / total)
    return mastery


def get_weak_topics(mastery: dict, threshold: int = WEAK_THRESHOLD):
    return sorted([t for t, pct in mastery.items() if pct < threshold], key=lambda t: mastery[t])


def get_strong_topics(mastery: dict, threshold: int = STRONG_THRESHOLD):
    return sorted([t for t, pct in mastery.items() if pct >= threshold], key=lambda t: -mastery[t])


def generate_recommendation(mastery: dict):
    if not mastery:
        return "Take a quiz first so I can figure out where you need the most practice."

    weak = get_weak_topics(mastery)
    strong = get_strong_topics(mastery)

    lines = []
    if weak:
        worst = weak[0]
        lines.append(
            f"Your weakest area is **{worst}** ({mastery[worst]}% mastery). "
            f"Revise the **{worst}** section and attempt another quiz on it."
        )
        if len(weak) > 1:
            others = ", ".join(f"**{t}** ({mastery[t]}%)" for t in weak[1:4])
            lines.append(f"Also keep an eye on: {others}.")
    else:
        lines.append("Great work — no clearly weak topics detected yet. Keep quizzing to stay sharp!")

    if strong:
        best = ", ".join(f"**{t}** ({mastery[t]}%)" for t in strong[:3])
        lines.append(f"You're doing well in: {best}.")

    return "\n\n".join(lines)


def render_progress_bar_text(mastery: dict, width: int = 20):
    """Text/ASCII style bar rendering, useful for simple display fallback."""
    lines = []
    for topic, pct in sorted(mastery.items(), key=lambda x: -x[1]):
        filled = int(width * pct / 100)
        bar = "█" * filled + "░" * (width - filled)
        lines.append(f"{topic:<20} {bar} {pct}%")
    return "\n".join(lines)
