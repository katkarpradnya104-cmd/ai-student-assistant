"""
qa_engine.py
------------
"Smart Ask My Notes" - context-aware academic Q&A over the student's own
uploaded material.

Handles:
  * Semantic retrieval of the most relevant chunks for a query
  * Follow-up question resolution (pronoun / ellipsis handling) so that
    "Explain it in simple words" correctly refers to the previous topic
  * Extractive-with-light-synthesis answer generation from retrieved chunks
  * Explicit "not found in your notes" fallback instead of hallucinating
"""

import re

from modules.preprocessing import sent_tokenize, extract_keywords
from modules.llm_client import call_llm, LLMError

# Phrases that signal the question is a follow-up referring to the
# previously discussed topic rather than introducing a brand-new one.
FOLLOWUP_PATTERNS = [
    r"^\s*(explain|what about|why|how|and|also|more on)\b.*\b(it|this|that|these|those)\b",
    r"^\s*(explain it|simplify|elaborate|go on|continue|tell me more)\b",
    r"^\s*(what are its|what is its|how is it|why is it)\b",
    r"^\s*(give (me )?an example|example\??)\s*$",
    r"^\s*(simplify|simpler|in simple words)\s*$",
]

PRONOUN_RE = re.compile(r"\b(it|this|that|its|these|those)\b", re.IGNORECASE)


def is_followup(query: str) -> bool:
    q = query.strip().lower()
    if len(q.split()) <= 6 and PRONOUN_RE.search(q):
        return True
    for pat in FOLLOWUP_PATTERNS:
        if re.search(pat, q):
            return True
    return False


def resolve_query(query: str, last_topic: str):
    """If the query looks like a follow-up and we have a remembered topic,
    rewrite it so the retriever has something concrete to search for."""
    if last_topic and is_followup(query):
        # Replace bare pronouns with the last topic; otherwise just append context.
        if PRONOUN_RE.search(query):
            rewritten = PRONOUN_RE.sub(last_topic, query)
        else:
            rewritten = f"{query} ({last_topic})"
        return rewritten, True
    return query, False


def _infer_topic_from_query(query: str, keywords_from_chunks):
    """Pick a short topic label to remember for follow-ups: prefer a
    keyword phrase already present in the query, else the query itself."""
    q_l = query.lower()
    for kw in keywords_from_chunks:
        if kw.lower() in q_l:
            return kw
    # strip common question words to get a topic guess
    cleaned = re.sub(
        r"^(what is|what are|explain|define|describe|tell me about|how does|how is)\s+",
        "", q_l
    ).strip("? .")
    return cleaned if cleaned else query


def generate_answer(query: str, retrieved, doc_title: str = "your notes"):
    """Compose an answer from retrieved (chunk, score) pairs.

    Uses extractive synthesis: pull the most relevant sentences out of the
    retrieved chunks (ranked by keyword overlap with the query) rather than
    dumping the entire chunk, then present with source page references.
    """
    if not retrieved:
        return {
            "answer": (
                f"I couldn't find this in {doc_title}. In offline mode I can only answer from "
                "your uploaded notes — try rephrasing, check a different section, or add a free "
                "API key in Settings so I can also answer things outside your notes like a "
                "normal chatbot."
            ),
            "sources": [],
            "found": False,
        }

    query_terms = set(w.lower() for w in re.findall(r"[a-zA-Z]+", query) if len(w) > 2)

    scored_sentences = []
    for chunk, chunk_score in retrieved:
        for sent in sent_tokenize(chunk["text"]):
            sent_terms = set(w.lower() for w in re.findall(r"[a-zA-Z]+", sent))
            overlap = len(query_terms & sent_terms)
            relevance = overlap + chunk_score  # combine lexical overlap + semantic score
            scored_sentences.append((relevance, sent, chunk["page"]))

    scored_sentences.sort(key=lambda x: -x[0])
    top_sentences = scored_sentences[:5] if scored_sentences else []

    # De-duplicate near-identical sentences while preserving order of relevance
    seen = set()
    picked = []
    for _, sent, page in top_sentences:
        key = sent[:50].lower()
        if key not in seen:
            seen.add(key)
            picked.append((sent, page))
    picked = picked[:4]

    answer_text = " ".join(s for s, _ in picked)
    pages = sorted(set(p for _, p in picked if p is not None))
    source_note = f"(Source: page/section {', '.join(str(p) for p in pages)})" if pages else ""

    return {
        "answer": f"{answer_text}\n\n{source_note}".strip(),
        "sources": pages,
        "found": True,
        "top_chunk_keywords": retrieved[0][0].get("keywords", []) if retrieved else [],
    }


def answer_question(query: str, store, last_topic: str = None, doc_title="your notes"):
    """Full pipeline: resolve follow-up -> semantic search -> answer generation.

    Returns dict: {answer, sources, found, new_topic, was_followup}
    """
    resolved_query, was_followup = resolve_query(query, last_topic)

    retrieved = store.search(resolved_query, top_k=4)
    if not retrieved:
        # try the raw (un-rewritten) query as a second attempt
        retrieved = store.search(query, top_k=4)

    result = generate_answer(resolved_query, retrieved, doc_title=doc_title)

    all_keywords = result.get("top_chunk_keywords", [])
    new_topic = _infer_topic_from_query(query if not was_followup else resolved_query, all_keywords)

    result["new_topic"] = new_topic if result["found"] else last_topic
    result["was_followup"] = was_followup
    result["resolved_query"] = resolved_query
    return result


def build_rag_messages(query, retrieved, chat_history, doc_title="your notes"):
    """Builds a messages[] list for a chat-completions call: a system
    prompt that grounds the model strictly in the retrieved note chunks,
    plus recent conversation turns (so the LLM can resolve natural
    follow-ups like "explain it simply" using real dialogue context
    instead of the regex-based heuristic used in the offline fallback),
    plus the new query.
    """
    if retrieved:
        context_parts = [f"(Page/section {c.get('page')}): {c['text']}" for c, _ in retrieved]
        context_text = "\n\n".join(context_parts)
    else:
        context_text = "(No relevant passages were found in the student's notes for this question.)"

    system_prompt = (
        "You are a friendly, knowledgeable study tutor chatting with a student. They've "
        f"uploaded notes ('{doc_title}'), given below as NOTES CONTEXT.\n\n"
        "How to answer:\n"
        "1. If the notes contain relevant material, lead with that — it's specific to what "
        "they're studying, so prefer it over generic knowledge and mention the page/section.\n"
        "2. If the notes are relevant but incomplete, use them as the base and fill gaps with "
        "your own knowledge, making clear which part came from their notes vs. general knowledge.\n"
        "3. If the question isn't covered in the notes at all (or no notes are relevant — e.g. "
        "small talk, a general question, math, something from a different subject), just answer "
        "it normally using your own knowledge, like any helpful chatbot would. Don't refuse or "
        "say 'not in your notes' for things that were never supposed to be in their notes.\n"
        "Be clear, encouraging, and reasonably concise — like a good tutor explaining out loud.\n\n"
        f"--- NOTES CONTEXT ---\n{context_text}\n--- END CONTEXT ---"
    )

    messages = [{"role": "system", "content": system_prompt}]
    for turn in chat_history[-8:]:
        if turn.get("role") in ("user", "assistant"):
            messages.append({"role": turn["role"], "content": turn["content"]})
    messages.append({"role": "user", "content": query})
    return messages


def llm_chat_answer(query, store, chat_history, provider, api_key, model=None,
                     last_topic=None, doc_title="your notes"):
    """ChatGPT-style RAG pipeline: retrieval/grounding is still pure NLP
    (semantic search over the student's own notes); only the final
    answer's phrasing comes from the LLM. Falls back to the fully local,
    pure-extractive pipeline (generate_answer) if the LLM call fails for
    any reason — no key configured, network error, rate limit, model no
    longer available, etc. — so the assistant always answers something
    useful.
    """
    resolved_query, was_followup = resolve_query(query, last_topic)
    retrieved = store.search(resolved_query, top_k=5)
    if not retrieved:
        retrieved = store.search(query, top_k=5)

    messages = build_rag_messages(query, retrieved, chat_history, doc_title=doc_title)

    fallback_used = False
    fallback_error = None
    try:
        answer_text = call_llm(provider, api_key, messages, model=model)
    except LLMError as e:
        fallback = generate_answer(resolved_query, retrieved, doc_title=doc_title)
        answer_text = fallback["answer"]
        fallback_used = True
        fallback_error = str(e)

    all_keywords = retrieved[0][0].get("keywords", []) if retrieved else []
    new_topic = _infer_topic_from_query(query if not was_followup else resolved_query, all_keywords)
    pages = sorted(set(c.get("page") for c, _ in retrieved if c.get("page") is not None))

    return {
        "answer": answer_text,
        "sources": pages,
        "found": bool(retrieved),
        "new_topic": new_topic if retrieved else last_topic,
        "was_followup": was_followup,
        "resolved_query": resolved_query,
        "fallback_used": fallback_used,
        "fallback_error": fallback_error,
    }
