"""
storage.py
----------
Simple local JSON-file persistence, scoped per user account, for:
  - the student's uploaded document (as extracted chunks, so it can be
    re-indexed on next login without re-uploading the file)
  - chat conversations (ChatGPT-style history, a list of threads)
  - quiz/progress records
  - lightweight per-user settings (which LLM provider, and optionally a
    remembered API key — stored locally only, never transmitted anywhere
    except directly to that provider's API when the student chats)

Nothing here is a "real" production database — these are local JSON files
under ./data/user_data/<username>/, appropriate for a single-machine
student project.
"""

import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def _user_dir(username: str) -> str:
    path = os.path.join(DATA_DIR, "user_data", username)
    os.makedirs(path, exist_ok=True)
    return path


def _read_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------- document
def save_document(username, doc_name, chunks):
    path = os.path.join(_user_dir(username), "document.json")
    _write_json(path, {"doc_name": doc_name, "chunks": chunks})


def load_document(username):
    path = os.path.join(_user_dir(username), "document.json")
    data = _read_json(path, None)
    if not data:
        return None, None
    return data.get("doc_name"), data.get("chunks")


def clear_document(username):
    path = os.path.join(_user_dir(username), "document.json")
    if os.path.exists(path):
        os.remove(path)


# ------------------------------------------------------------ conversations
def load_conversations(username):
    path = os.path.join(_user_dir(username), "conversations.json")
    return _read_json(path, [])


def save_conversations(username, conversations):
    path = os.path.join(_user_dir(username), "conversations.json")
    _write_json(path, conversations)


# ------------------------------------------------------------------ progress
def load_progress(username):
    path = os.path.join(_user_dir(username), "progress.json")
    return _read_json(path, {})


def save_progress(username, progress):
    path = os.path.join(_user_dir(username), "progress.json")
    _write_json(path, progress)


# ------------------------------------------------------------------ settings
def load_settings(username):
    path = os.path.join(_user_dir(username), "settings.json")
    return _read_json(path, {"provider": None, "api_key": None, "remember_key": False})


def save_settings(username, settings):
    path = os.path.join(_user_dir(username), "settings.json")
    _write_json(path, settings)
