"""
embeddings_store.py
--------------------
Builds vector representations of the notes' chunks and performs semantic
similarity search against student queries.

Primary method: sentence-transformers (all-MiniLM-L6-v2) sentence
embeddings + cosine similarity.

Fallback method: if sentence-transformers / its model weights are not
available (e.g. no internet access at runtime), we transparently fall back
to a TF-IDF vector space model with cosine similarity, so the retrieval
pipeline still works end-to-end for a demo. Both paths demonstrate the
same underlying NLP concept: mapping text to vectors and comparing them
with a similarity measure.
"""

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

from modules.preprocessing import STOPWORDS

_MODEL_NAME = "all-MiniLM-L6-v2"


class EmbeddingStore:
    def __init__(self):
        self.chunks = []
        self.vectors = None
        self.backend = None  # "sentence-transformers" or "tfidf"
        self._model = None
        self._tfidf = None

    # ------------------------------------------------------------------
    def _load_sentence_transformer(self):
        if self._model is not None:
            return self._model
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(_MODEL_NAME)
            return self._model
        except Exception:
            return None

    # ------------------------------------------------------------------
    def build(self, chunks):
        """chunks: list of dicts with a 'text' field (from preprocessing.chunk_text)."""
        self.chunks = chunks
        texts = [c["text"] for c in chunks]

        model = self._load_sentence_transformer()
        if model is not None:
            try:
                self.vectors = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
                self.backend = "sentence-transformers"
                return
            except Exception:
                pass

        # Fallback: TF-IDF vector space
        self._tfidf = TfidfVectorizer(stop_words=list(STOPWORDS), ngram_range=(1, 2), max_features=5000)
        self.vectors = self._tfidf.fit_transform(texts)
        self.backend = "tfidf"

    # ------------------------------------------------------------------
    def _embed_query(self, query: str):
        if self.backend == "sentence-transformers":
            model = self._load_sentence_transformer()
            return model.encode([query], show_progress_bar=False, convert_to_numpy=True)
        else:
            return self._tfidf.transform([query])

    # ------------------------------------------------------------------
    def search(self, query: str, top_k: int = 4, min_score: float = 0.15):
        """Returns list of (chunk_dict, similarity_score) sorted descending."""
        if not self.chunks or self.vectors is None:
            return []

        q_vec = self._embed_query(query)
        sims = cosine_similarity(q_vec, self.vectors)[0]
        order = np.argsort(sims)[::-1][:top_k]

        results = []
        for idx in order:
            score = float(sims[idx])
            if score >= min_score:
                results.append((self.chunks[idx], score))
        return results

    # ------------------------------------------------------------------
    def search_by_keyword(self, keyword: str, top_k: int = 5):
        """Lexical fallback search: useful when semantic score is too low,
        or for locating a specific named topic (e.g. for comparison mode)."""
        keyword_l = keyword.lower()
        scored = []
        for c in self.chunks:
            text_l = c["text"].lower()
            count = text_l.count(keyword_l)
            kw_hit = any(keyword_l in kw.lower() for kw in c.get("keywords", []))
            if count > 0 or kw_hit:
                scored.append((c, count + (2 if kw_hit else 0)))
        scored.sort(key=lambda x: -x[1])
        return scored[:top_k]
