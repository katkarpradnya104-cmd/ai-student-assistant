"""
comparison_engine.py
---------------------
Smart Comparison Mode: detects "difference between X and Y" style questions
and builds a structured side-by-side comparison sourced from the student's
own notes wherever possible.
"""

import re

from modules.preprocessing import sent_tokenize

COMPARISON_PATTERNS = [
    re.compile(r"difference between\s+(.+?)\s+and\s+(.+?)(\?|$)", re.I),
    re.compile(r"compare\s+(.+?)\s+(?:and|with|to)\s+(.+?)(\?|$)", re.I),
    re.compile(r"(.+?)\s+vs\.?\s+(.+?)(\?|$)", re.I),
    re.compile(r"(.+?)\s+versus\s+(.+?)(\?|$)", re.I),
]

FEATURE_CUES = {
    "Method/Approach": re.compile(r"\b(method|approach|technique|algorithm|works by|process)\b", re.I),
    "Output/Result": re.compile(r"\b(output|result|produces|generates|yields)\b", re.I),
    "Accuracy/Performance": re.compile(r"\b(accura(cy|te)|performance|precision|efficient)\b", re.I),
    "Advantages": re.compile(r"\b(advantage|benefit|pro[s]?\b|strength)", re.I),
    "Disadvantages": re.compile(r"\b(disadvantage|drawback|con[s]?\b|limitation|weakness)", re.I),
    "Example": re.compile(r"\b(for example|for instance|e\.g\.|such as)\b", re.I),
}

NOT_FOUND = "Not explicitly covered for this feature in your notes."


def _mentions_many_other_terms(sent: str, term: str, other_term: str) -> bool:
    """A sentence like 'Techniques such as tokenization, stemming,
    lemmatization, POS tagging, NER... help computers process text' mentions
    the term, but only as one item in a long generic list — it doesn't
    actually describe the term itself. Detect that pattern so we don't treat
    such sentences as a term's defining/representative sentence."""
    comma_count = sent.count(",")
    has_such_as = re.search(r"\bsuch as\b", sent, re.I) is not None
    mentions_other = other_term.lower() in sent.lower()
    return has_such_as and comma_count >= 3 and mentions_other


def _subject_sentence(sent: str, term: str) -> bool:
    """True if the sentence appears to actually be *about* the term (the
    term is at or near the start), rather than merely containing it."""
    return re.match(rf"^\s*(the\s+)?{re.escape(term)}\b", sent, re.I) is not None


def _extract_features(term: str, other_term: str, chunks):
    """Scan chunks mentioning `term` and bucket relevant sentences by
    feature cue, while keeping an ordered, de-duplicated list of candidate
    'core' sentences (best-described-first) to draw on for any row that
    has no feature-specific match — so unmatched rows don't all collapse
    onto the exact same sentence.
    """
    term_l = term.lower()
    features = {label: [] for label in FEATURE_CUES}

    good_candidates = []   # sentences clearly about this term, not a list-mention
    weak_candidates = []   # sentences that just happen to contain the term
    seen = set()

    for chunk in chunks:
        text_l = chunk["text"].lower()
        if term_l not in text_l:
            continue
        for sent in sent_tokenize(chunk["text"]):
            if term_l not in sent.lower():
                continue
            key = sent[:60].lower()
            if key in seen:
                continue
            seen.add(key)

            for label, cue in FEATURE_CUES.items():
                if cue.search(sent):
                    features[label].append(sent)

            if _mentions_many_other_terms(sent, term, other_term):
                weak_candidates.append(sent)
            elif _subject_sentence(sent, term):
                good_candidates.insert(0, sent)  # subject sentences go first
            else:
                good_candidates.append(sent)

    core_sentences = good_candidates + weak_candidates
    return features, core_sentences


def build_comparison(term_a: str, term_b: str, store):
    """store: EmbeddingStore already built over the uploaded notes."""
    results_a = store.search_by_keyword(term_a, top_k=6) or store.search(term_a, top_k=6)
    results_b = store.search_by_keyword(term_b, top_k=6) or store.search(term_b, top_k=6)

    chunks_a = [r[0] if isinstance(r, tuple) else r for r in results_a]
    chunks_b = [r[0] if isinstance(r, tuple) else r for r in results_b]

    features_a, core_a = _extract_features(term_a, term_b, chunks_a)
    features_b, core_b = _extract_features(term_b, term_a, chunks_b)

    found = bool(core_a) or bool(core_b)

    def pick(features_for_label, core_list, used):
        """Prefer a feature-specific sentence; otherwise take the next
        not-yet-used core sentence (so different rows get different
        content instead of all repeating core[0]); only fall back to
        repeating a sentence if we've genuinely run out of distinct ones."""
        if features_for_label:
            for cand in features_for_label:
                if cand not in used:
                    used.add(cand)
                    return cand
            return features_for_label[0]
        for cand in core_list:
            if cand not in used:
                used.add(cand)
                return cand
        return core_list[0] if core_list else NOT_FOUND

    used_a, used_b = set(), set()
    table_rows = []
    for label in FEATURE_CUES:
        val_a = pick(features_a[label], core_a, used_a)
        val_b = pick(features_b[label], core_b, used_b)
        table_rows.append({"feature": label, "a": val_a, "b": val_b})

    return {
        "term_a": term_a,
        "term_b": term_b,
        "found": found,
        "rows": table_rows,
        "summary_a": core_a[0] if core_a else f"'{term_a}' was not clearly found in your uploaded notes.",
        "summary_b": core_b[0] if core_b else f"'{term_b}' was not clearly found in your uploaded notes.",
    }


def detect_comparison(query: str):
    """Returns (term_a, term_b) if the query looks like a comparison question, else None."""
    for pattern in COMPARISON_PATTERNS:
        m = pattern.search(query)
        if m:
            term_a = m.group(1).strip(" ?.,")
            term_b = m.group(2).strip(" ?.,")
            term_a = re.sub(r"^(the|a|an)\s+", "", term_a, flags=re.I)
            term_b = re.sub(r"^(the|a|an)\s+", "", term_b, flags=re.I)
            if term_a and term_b:
                return term_a, term_b
    return None
