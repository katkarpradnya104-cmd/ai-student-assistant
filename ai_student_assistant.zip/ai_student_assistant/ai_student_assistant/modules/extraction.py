"""
extraction.py
-------------
Extracts raw text (page-wise for PDFs, section-wise for DOCX) from uploaded
study material so it can be fed into the preprocessing / chunking pipeline.
"""

import io


def extract_from_pdf(file_bytes: bytes):
    """Returns list of {"page": int, "text": str} using pypdf."""
    from pypdf import PdfReader

    reader = PdfReader(io.BytesIO(file_bytes))
    pages = []
    for i, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        pages.append({"page": i, "text": text})
    return pages


def extract_from_docx(file_bytes: bytes):
    """Returns list of {"page": section_index, "text": str} using python-docx.
    DOCX has no native 'pages', so we group paragraphs into pseudo-sections
    based on heading styles (falls back to one big section)."""
    import docx

    document = docx.Document(io.BytesIO(file_bytes))
    sections = []
    current_heading = "Document"
    current_paras = []
    section_index = 1

    def flush():
        nonlocal section_index
        text = "\n".join(current_paras).strip()
        if text:
            sections.append({"page": section_index, "text": f"{current_heading}\n{text}"})
            section_index += 1

    for para in document.paragraphs:
        style = (para.style.name or "").lower() if para.style else ""
        if "heading" in style and current_paras:
            flush()
            current_paras = []
            current_heading = para.text.strip() or current_heading
        elif "heading" in style:
            current_heading = para.text.strip() or current_heading
        else:
            if para.text.strip():
                current_paras.append(para.text)

    flush()

    # Also pull any table content (common in notes for comparisons/definitions)
    for table in document.tables:
        rows_text = []
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                rows_text.append(" | ".join(cells))
        if rows_text:
            sections.append({"page": section_index, "text": "Table\n" + "\n".join(rows_text)})
            section_index += 1

    if not sections:
        full_text = "\n".join(p.text for p in document.paragraphs)
        sections = [{"page": 1, "text": full_text}]

    return sections


def extract_document(filename: str, file_bytes: bytes):
    """Dispatch based on file extension. Returns list of page/section dicts."""
    name = filename.lower()
    if name.endswith(".pdf"):
        return extract_from_pdf(file_bytes)
    elif name.endswith(".docx"):
        return extract_from_docx(file_bytes)
    elif name.endswith(".txt"):
        text = file_bytes.decode("utf-8", errors="ignore")
        return [{"page": 1, "text": text}]
    else:
        raise ValueError(f"Unsupported file type: {filename}. Please upload a PDF, DOCX, or TXT file.")
