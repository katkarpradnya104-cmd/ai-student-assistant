"""
summarizer.py
-------------
Intelligent Notes Summarizer.

Implements extractive summarization via a TextRank-style algorithm:
  1. Segment text into sentences
  2. Represent each sentence as a TF-IDF vector
  3. Build a sentence-similarity graph
  4. Rank sentences with PageRank (networkx)
  5. Select top-ranked sentences (in original order) as the summary

This identifies *important* information (based on how central/representative
a sentence is to the document) rather than naively truncating text.

Three output formats are supported: quick, standard, exam.
"""

import re

import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from modules.preprocessing import sent_tokenize, extract_keywords, STOPWORDS
from modules.explain_engine import (
    ADVANTAGE_CUES, DISADVANTAGE_CUES, EXAMPLE_CUES, WORKING_CUES, DEFINITION_PATTERNS,
    _find_topic_definition,
)


def _rank_sentences(sentences):
    if len(sentences) <= 1:
        return list(range(len(sentences)))

    try:
        vec = TfidfVectorizer(stop_words=list(STOPWORDS))
        matrix = vec.fit_transform(sentences)
        sim_matrix = cosine_similarity(matrix)

        graph = nx.from_numpy_array(sim_matrix)
        scores = nx.pagerank(graph, max_iter=200)
        ranked_idx = sorted(scores, key=lambda i: -scores[i])
        return ranked_idx
    except Exception:
        # fallback: rank by sentence length (proxy for informativeness)
        return sorted(range(len(sentences)), key=lambda i: -len(sentences[i]))


def _select_top_k_in_order(sentences, ranked_idx, k):
    top_idx = sorted(ranked_idx[:k])
    return [sentences[i] for i in top_idx]


def quick_revision(text: str, max_points: int = 5) -> str:
    sentences = sent_tokenize(text)
    if not sentences:
        return "No content available to summarize."
    ranked = _rank_sentences(sentences)
    top = _select_top_k_in_order(sentences, ranked, min(max_points, len(sentences)))
    bullets = "\n".join(f"• {s}" for s in top)
    return bullets


def standard_summary(text: str, max_sentences: int = 6) -> str:
    sentences = sent_tokenize(text)
    if not sentences:
        return "No content available to summarize."
    ranked = _rank_sentences(sentences)
    top = _select_top_k_in_order(sentences, ranked, min(max_sentences, len(sentences)))
    return " ".join(top)


def exam_notes(text: str, topic: str = "Topic") -> dict:
    sentences = sent_tokenize(text)
    definition = _find_topic_definition(sentences, topic)

    working = [s for s in sentences if WORKING_CUES.search(s)][:3]
    advantages = [s for s in sentences if ADVANTAGE_CUES.search(s) and not DISADVANTAGE_CUES.search(s)][:3]
    disadvantages = [s for s in sentences if DISADVANTAGE_CUES.search(s)][:3]
    examples = [s for s in sentences if EXAMPLE_CUES.search(s)][:2]

    used = set(filter(None, [definition] + working + advantages + disadvantages + examples))
    remaining = [s for s in sentences if s not in used]
    ranked_remaining_idx = _rank_sentences(remaining) if remaining else []
    key_concepts = _select_top_k_in_order(remaining, ranked_remaining_idx, min(4, len(remaining)))

    keywords = extract_keywords(text, top_n=8)

    return {
        "topic": topic,
        "definition": definition or "Not explicitly stated in the source text.",
        "key_concepts": key_concepts or ["Not enough distinct content to extract further key concepts."],
        "working": working or ["Not explicitly described in the source text."],
        "important_points": key_concepts[:2] if key_concepts else [],
        "advantages": advantages or ["Not mentioned in the source text."],
        "disadvantages": disadvantages or ["Not mentioned in the source text."],
        "examples": examples or ["No explicit example found in the source text."],
        "keywords": keywords,
    }


def summarize(text: str, mode: str, topic: str = "Topic"):
    """mode in {"quick", "standard", "exam"}"""
    mode = mode.lower()
    if mode == "quick":
        return {"type": "text", "content": quick_revision(text)}
    elif mode == "exam":
        return {"type": "structured", "content": exam_notes(text, topic=topic)}
    else:
        return {"type": "text", "content": standard_summary(text)}
