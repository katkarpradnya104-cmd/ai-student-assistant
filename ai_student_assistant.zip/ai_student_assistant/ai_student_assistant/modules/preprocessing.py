"""
preprocessing.py
----------------
Core NLP preprocessing utilities for the AI Student Assistant.

Implements, from scratch (no external data downloads required):
  * Text cleaning
  * Sentence segmentation (regex-based sentence boundary detection)
  * Word tokenization
  * Stopword removal
  * Stemming (Porter stemmer, algorithmic - no corpus download needed)
  * Keyword extraction (TF-IDF based)
  * Text chunking with overlap (for semantic retrieval)

Keeping this dependency-light (no nltk punkt / corpora downloads) means the
project runs fully offline, which matters for a demo/viva environment.
"""

import re
from collections import Counter

from sklearn.feature_extraction.text import TfidfVectorizer

try:
    from nltk.stem import PorterStemmer  # algorithmic, no data download needed
    _stemmer = PorterStemmer()
except Exception:  # pragma: no cover - safety net if nltk isn't installed
    _stemmer = None


# A compact, hand-curated stopword list so we avoid needing nltk's
# 'stopwords' corpus download (which requires internet access to nltk_data).
STOPWORDS = set("""
a about above after again against all am an and any are aren't as at be
because been before being below between both but by can't cannot could
couldn't did didn't do does doesn't doing don't down during each few for
from further had hadn't has hasn't have haven't having he he'd he'll he's
her here here's hers herself him himself his how how's i i'd i'll i'm i've
if in into is isn't it it's its itself let's me more most mustn't my myself
no nor not of off on once only or other ought our ours ourselves out over
own same shan't she she'd she'll she's should shouldn't so some such than
that that's the their theirs them themselves then there there's these they
they'd they'll they're they've this those through to too under until up
very was wasn't we we'd we'll we're we've were weren't what what's when
when's where where's which while who who's whom why why's with won't
would wouldn't you you'd you'll you're you've your yours yourself yourselves
""".split())


def clean_text(text: str) -> str:
    """Normalize whitespace, remove control characters, fix hyphenation
    artifacts introduced by PDF extraction (e.g. line-break hyphens)."""
    if not text:
        return ""
    text = text.replace("\x0c", " ")
    # join words split across a line break by a hyphen: "infor-\nmation" -> "information"
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    # PDFs often extract a numbered section heading glued directly onto the
    # paragraph that follows it, with the heading's own last word repeated
    # as the paragraph's first word (e.g. "3.3 Stemming Stemming reduces
    # words to..."). Drop the redundant "N.N Heading" prefix so the
    # sentence tokenizer sees a clean sentence instead of a fused blob.
    text = re.sub(r"\b\d+(?:\.\d+)+\s+([A-Z][A-Za-z\-]{2,30})\s+(?=\1\b)", "", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" *\n *", "\n", text)
    return text.strip()


_SENT_SPLIT_RE = re.compile(
    r"(?<!\b[A-Z])(?<!\betc)(?<!\bMr)(?<!\bMs)(?<!\bDr)(?<=[.!?])\s+(?=[A-Z0-9\"'])"
)

# PDF text extraction very often glues a numbered section heading straight
# onto the start of the following sentence with no real line break in
# between (e.g. "3.3 Stemming" + "Stemming reduces words to..." becomes the
# single run-on "3.3 Stemming Stemming reduces words to..."). Since the
# heading's topic word is almost always the same word the sentence itself
# starts with, this leaves a leading section number and a duplicated word.
# Strip both so no answer ever surfaces raw heading numbering.
_LEADING_HEADING_NUM_RE = re.compile(r"^\s*\d+(?:\.\d+)*\.?\s+")
_LEADING_DUP_WORD_RE = re.compile(r"^(\w[\w\-']*)\s+\1\b", re.IGNORECASE)


def _strip_heading_artifacts(sentence: str) -> str:
    """Remove a leading section-number heading and a resulting duplicated
    leading word, e.g. '3.3 Stemming Stemming reduces...' -> 'Stemming
    reduces...'. Safe to run on any sentence — has no effect on ordinary
    text that never had a heading glued onto it."""
    cleaned = _LEADING_HEADING_NUM_RE.sub("", sentence)
    cleaned = _LEADING_DUP_WORD_RE.sub(r"\1", cleaned)
    return cleaned.strip()


def sent_tokenize(text: str):
    """Lightweight regex-based sentence tokenizer.

    Avoids the need for nltk's punkt data download while still handling
    the common abbreviation edge cases reasonably well for academic text.
    """
    if not text:
        return []
    # Treat bullet points / newlines as sentence boundaries too.
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    sentences = []
    for para in paragraphs:
        # protect common abbreviations from being split
        protected = re.sub(r"\b(e\.g|i\.e|etc|vs|Fig|fig|approx)\.", r"\1<DOT>", para)
        parts = _SENT_SPLIT_RE.split(protected)
        for p in parts:
            p = p.replace("<DOT>", ".").strip()
            p = _strip_heading_artifacts(p)
            if p:
                sentences.append(p)
    return sentences


_WORD_RE = re.compile(r"[A-Za-z][A-Za-z\-']*|\d+(?:\.\d+)?")


def word_tokenize(text: str):
    """Simple regex word tokenizer (keeps hyphenated/apostrophe words)."""
    return _WORD_RE.findall(text)


def remove_stopwords(tokens):
    return [t for t in tokens if t.lower() not in STOPWORDS and len(t) > 1]


def stem(word: str) -> str:
    if _stemmer:
        try:
            return _stemmer.stem(word)
        except Exception:
            return word.lower()
    return word.lower()


def preprocess_for_matching(text: str):
    """Full pipeline: tokenize -> lowercase -> remove stopwords -> stem.
    Used internally for lexical fallback matching / keyword comparison."""
    tokens = word_tokenize(text)
    tokens = remove_stopwords(tokens)
    return [stem(t) for t in tokens]


def extract_keywords(text: str, top_n: int = 8):
    """Extract salient keywords/phrases from a block of text using TF-IDF
    scoring over its own sentences (a lightweight RAKE-like heuristic that
    needs no external corpus)."""
    sentences = sent_tokenize(text)
    if not sentences:
        return []
    if len(sentences) == 1:
        # Not enough documents for TF-IDF variance; fall back to frequency.
        tokens = remove_stopwords(word_tokenize(text.lower()))
        freq = Counter(tokens)
        return [w for w, _ in freq.most_common(top_n)]

    try:
        vec = TfidfVectorizer(
            stop_words=list(STOPWORDS),
            ngram_range=(1, 2),
            max_features=2000,
        )
        matrix = vec.fit_transform(sentences)
        scores = matrix.sum(axis=0).A1
        terms = vec.get_feature_names_out()
        ranked = sorted(zip(terms, scores), key=lambda x: -x[1])
        keywords = []
        seen_words = set()
        for term, _score in ranked:
            words_in_term = set(term.split())
            if words_in_term & seen_words:
                continue
            keywords.append(term)
            seen_words |= words_in_term
            if len(keywords) >= top_n:
                break
        return keywords
    except Exception:
        tokens = remove_stopwords(word_tokenize(text.lower()))
        freq = Counter(tokens)
        return [w for w, _ in freq.most_common(top_n)]


def chunk_text(pages, chunk_size_words: int = 130, overlap_words: int = 30):
    """Split extracted document pages into overlapping chunks suitable for
    semantic embedding + retrieval.

    Parameters
    ----------
    pages : list of dict  -> [{"page": int, "text": str}, ...]

    Returns
    -------
    list of dict -> [{"chunk_id": int, "text": str, "page": int, "keywords": [...]}]
    """
    chunks = []
    chunk_id = 0
    for page in pages:
        page_num = page.get("page")
        text = clean_text(page.get("text", ""))
        if not text:
            continue
        sentences = sent_tokenize(text)
        if not sentences:
            continue

        current_words = []
        current_sentences = []

        def flush():
            nonlocal chunk_id
            if current_sentences:
                chunk_text_val = " ".join(current_sentences).strip()
                if chunk_text_val:
                    chunks.append({
                        "chunk_id": chunk_id,
                        "text": chunk_text_val,
                        "page": page_num,
                        "keywords": extract_keywords(chunk_text_val, top_n=5),
                    })
                    chunk_id += 1

        for sent in sentences:
            words = sent.split()
            current_sentences.append(sent)
            current_words.extend(words)
            if len(current_words) >= chunk_size_words:
                flush()
                # start next chunk with overlap
                overlap_sents = []
                overlap_w = 0
                for s in reversed(current_sentences):
                    overlap_sents.insert(0, s)
                    overlap_w += len(s.split())
                    if overlap_w >= overlap_words:
                        break
                current_sentences = overlap_sents
                current_words = " ".join(overlap_sents).split()

        flush()

    return chunks
