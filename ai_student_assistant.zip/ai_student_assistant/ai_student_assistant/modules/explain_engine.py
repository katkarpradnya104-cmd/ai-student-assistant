"""
explain_engine.py
------------------
"Explain Like I'm a Student" - adaptive explanation mode.

Transforms retrieved note content into different registers:
  normal   -> lightly cleaned version of the source text
  simple   -> shorter sentences, jargon swapped for plain-English synonyms
  example  -> source content + a worked example (from notes if present,
              otherwise a generated illustrative template)
  exam     -> structured breakdown: Definition / Main Points / Working /
              Example / Advantages-Disadvantages / Keywords
  detail   -> the fullest concatenation of all relevant retrieved chunks
"""

import re

from modules.preprocessing import sent_tokenize, extract_keywords

# A small jargon -> plain-English simplification dictionary. This is a
# deliberately simple, transparent rule-based lexical substitution step
# (a classic controlled-NLG technique) rather than a black box.
JARGON_MAP = {
    r"\butiliz(e|es|ed|ing)\b": "use",
    r"\bfacilitate(s|d)?\b": "help",
    r"\bsubsequently\b": "then",
    r"\bconsequently\b": "so",
    r"\btherefore\b": "so",
    r"\bmoreover\b": "also",
    r"\bfurthermore\b": "also",
    r"\bhence\b": "so",
    r"\bheuristic\b": "rule of thumb",
    r"\bempirical(ly)?\b": "based on observed data",
    r"\bstochastic\b": "random/probability-based",
    r"\bconstitute(s|d)?\b": "make up",
    r"\bnumerous\b": "many",
    r"\bapproximately\b": "about",
    r"\bpertaining to\b": "about",
    r"\bin conjunction with\b": "together with",
    r"\bexhibit(s|ed)?\b": "show",
    r"\bcomprises?\b": "is made up of",
    r"\bdenote(s|d)?\b": "represent",
    r"\bnotwithstanding\b": "despite",
}

DEFINITION_PATTERNS = [
    # allows an optional parenthetical abbreviation between the term and the
    # copula, e.g. "A Hidden Markov Model (HMM) is a statistical model..."
    r"([A-Z][A-Za-z0-9\-\s]{2,40}?)(?:\s*\([A-Za-z0-9]{2,8}\))?\s+(?:is|are|refers to|is defined as|can be defined as)\s+",
]

ADVANTAGE_CUES = re.compile(r"\b(advantage|benefit|pro[s]?\b|strength)", re.I)
DISADVANTAGE_CUES = re.compile(r"\b(disadvantage|drawback|con[s]?\b|limitation|weakness)", re.I)
EXAMPLE_CUES = re.compile(r"\b(for example|for instance|e\.g\.|consider the case|to illustrate)", re.I)
WORKING_CUES = re.compile(r"\b(works by|process|steps?|algorithm|procedure|first|then|finally)\b", re.I)


def _simplify_sentence(sentence: str) -> str:
    out = sentence
    for pattern, replacement in JARGON_MAP.items():
        out = re.sub(pattern, replacement, out, flags=re.IGNORECASE)
    # Split overly long sentences at conjunctions for readability.
    if len(out.split()) > 28:
        out = re.split(r",\s*(?:which|and|but)\s+", out, maxsplit=1)[0].strip()
        if not out.endswith("."):
            out += "."
    return out


def explain_simple(combined_text: str) -> str:
    sentences = sent_tokenize(combined_text)[:6]
    simplified = [_simplify_sentence(s) for s in sentences]
    intro = "In simple words:\n"
    bullets = "\n".join(f"• {s}" for s in simplified if s)
    return intro + bullets


def explain_normal(combined_text: str) -> str:
    sentences = sent_tokenize(combined_text)
    return " ".join(sentences[:6])


def explain_detail(combined_text: str) -> str:
    return combined_text.strip()


def _find_topic_definition(sentences, topic: str):
    """Prefer a definition-pattern sentence whose subject actually matches
    the requested topic; fall back to the first definition-like sentence,
    then to the first sentence overall."""
    topic_l = (topic or "").lower().strip()
    topic_words = set(w for w in re.findall(r"[a-z0-9]+", topic_l) if len(w) > 2)

    candidates = []
    for s in sentences:
        for pat in DEFINITION_PATTERNS:
            m = re.search(pat, s)
            if m:
                candidates.append((m.group(1).strip().lower(), s))
                break

    if topic_words:
        for term, s in candidates:
            term_words = set(re.findall(r"[a-z0-9]+", term))
            if term_words & topic_words or term in topic_l or topic_l in term:
                return s

    if candidates:
        return candidates[0][1]
    return sentences[0] if sentences else None


def _find_example(combined_text: str, sentences):
    for s in sentences:
        if EXAMPLE_CUES.search(s):
            return s
    return None


def explain_with_example(combined_text: str, topic: str) -> str:
    sentences = sent_tokenize(combined_text)
    base = " ".join(sentences[:3])
    existing_example = _find_example(combined_text, sentences)
    if existing_example:
        return f"{base}\n\nExample (from your notes): {existing_example}"
    else:
        return (
            f"{base}\n\n"
            f"Example: Imagine applying '{topic}' to a small, concrete case step by step — "
            f"this is not explicitly in your notes, so try working through a real instance "
            f"from your coursework and check it against the definition above."
        )


def explain_exam_mode(combined_text: str, topic: str) -> dict:
    """Builds the structured exam-answer format:
    Definition, Main Points, Working, Example, Advantages/Disadvantages, Keywords
    """
    sentences = sent_tokenize(combined_text)
    definition = _find_topic_definition(sentences, topic)

    working_sents = [s for s in sentences if WORKING_CUES.search(s)][:3]
    advantages = [s for s in sentences if ADVANTAGE_CUES.search(s) and not DISADVANTAGE_CUES.search(s)][:3]
    disadvantages = [s for s in sentences if DISADVANTAGE_CUES.search(s)][:3]
    example = _find_example(combined_text, sentences)

    # Main points: top remaining informative sentences (excluding ones already used)
    used = set(filter(None, [definition, example] + working_sents + advantages + disadvantages))
    remaining = [s for s in sentences if s not in used]
    main_points = remaining[:4] if remaining else sentences[1:4]

    keywords = extract_keywords(combined_text, top_n=6)

    return {
        "topic": topic,
        "definition": definition or "Not explicitly stated in your notes.",
        "main_points": main_points or ["Not enough detail found in your notes for additional points."],
        "working": working_sents or ["Working/process not explicitly described in your notes."],
        "example": example or "No explicit example found in your notes.",
        "advantages": advantages or ["Not mentioned in your notes."],
        "disadvantages": disadvantages or ["Not mentioned in your notes."],
        "keywords": keywords,
    }


def explain(combined_text: str, topic: str, mode: str):
    """Dispatch to the requested explanation mode.
    mode in {"normal", "simple", "example", "exam", "detail"}
    """
    mode = mode.lower()
    if mode == "simple":
        return {"type": "text", "content": explain_simple(combined_text)}
    elif mode == "example":
        return {"type": "text", "content": explain_with_example(combined_text, topic)}
    elif mode == "exam":
        return {"type": "structured", "content": explain_exam_mode(combined_text, topic)}
    elif mode == "detail":
        return {"type": "text", "content": explain_detail(combined_text)}
    else:
        return {"type": "text", "content": explain_normal(combined_text)}
